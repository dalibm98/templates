import {Routes} from '@angular/router';

import {AuthenticationComponent} from './pages/authentication/authentication.component';
import {ProductComponent} from './pages/product/product.component';
import {GroupComponent} from './pages/group_management/group.component';
import {UserComponent} from './pages/user_management/user.component';
import {UserActivateComponent} from './pages/user_settings/user-activate.component';
import {UserSettingsComponent} from './pages/user_settings/user-settings.component';
import {UserPasswordComponent} from './pages/user_settings/user-password.component';
import {UserForgotPasswordComponent} from './pages/user_settings/user-forgot-password.component';
import {UserResetPasswordComponent} from './pages/user_settings/user-reset-password.component';
import {UpdateCreatePanelComponent} from './pages/update/create/update-create-panel.component';
import {UpdateUploadComponent} from './pages/update/update-upload.component';
import {ConfirmDeactivateInterceptor} from './interceptor/confirm-deactivate.interceptor';
import {StatisticComponent} from './pages/statistic/statistic.component';

export const routes: Routes = [
  {
    path: 'login',
    component: AuthenticationComponent
  },
  {
    path: 'product',
    component: ProductComponent
  },
  {
    path: 'update_creation/:productUid',
    component: UpdateCreatePanelComponent
  },
  {
    path: 'upload/:updateUid',
    component: UpdateUploadComponent,
    canDeactivate: [ConfirmDeactivateInterceptor]
  },
  {
    path: 'statistics',
    component: StatisticComponent
  },
  {
    path: 'group_management',
    component: GroupComponent
  },
  {
    path: 'user_management',
    component: UserComponent
  },
  {
    path: 'user_activate',
    component: UserActivateComponent
  },
  {
    path: 'user_settings',
    component: UserSettingsComponent
  },
  {
    path: 'user_password',
    component: UserPasswordComponent
  },
  {
    path: 'user_forgot_password',
    component: UserForgotPasswordComponent
  },
  {
    path: 'user_reset_password',
    component: UserResetPasswordComponent
  }
];
