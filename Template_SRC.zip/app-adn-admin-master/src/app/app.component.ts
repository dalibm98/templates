import {Component} from '@angular/core';
import {NavigationEnd, Router} from '@angular/router';
import {filter} from 'rxjs/operators';

import {TranslateService} from '@ngx-translate/core';
import {defineLocale, enGbLocale, frLocale} from 'ngx-bootstrap';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {

  isLoginPage = false;
  isLoggedInPage = false;

  constructor(translate: TranslateService, router: Router) {
    translate.addLangs(['fr', 'en']);
    translate.setDefaultLang('fr');
    translate.use('fr');

    // Define locale for ngx-bootstrap
    defineLocale('en', enGbLocale);
    defineLocale('fr', frLocale);

    router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe(event => {
        if (event instanceof NavigationEnd) {
          this.isLoginPage = event.url.indexOf('login') !== -1;
          this.isLoggedInPage = AppComponent.isLoggedPageInRoute(event.url);
        }
      });
  }

  /**
   * Check if page at currentRouteUrl is a page where the user needs to be logged in
   * @param {string} currentRouteUrl
   * @returns {boolean}
   */
  private static isLoggedPageInRoute(currentRouteUrl: string) {
    return currentRouteUrl.indexOf('login') === -1 &&
      currentRouteUrl.indexOf('user_activate') === -1 &&
      currentRouteUrl.indexOf('user_forgot_password') === -1 &&
      currentRouteUrl.indexOf('reset_password') === -1;
  }
}
