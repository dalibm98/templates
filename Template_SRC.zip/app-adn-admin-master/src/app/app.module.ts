import {HTTP_INTERCEPTORS, HttpClient, HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule} from '@angular/router';
import {NgModule} from '@angular/core';
import {DatePipe} from '@angular/common';

import {routes} from './app-routing.module';
/* APP COMPONENTS/SERVICES/... */
// Main component
import {AppComponent} from './app.component';
// Interceptors
import {AuthInterceptor} from './interceptor/auth.interceptor';
import {HttpResponseInterceptor} from './interceptor/http-response.interceptor';
import {ConfirmDeactivateInterceptor} from './interceptor/confirm-deactivate.interceptor';
// Bar components
import {NavbarComponent} from './components/bar/navbar/navbar-component';
import {EditBarComponent} from './components/bar/edit-bar/edit-bar.component';
// Authentication
import {AuthenticationComponent} from './pages/authentication/authentication.component';
import {AuthenticationService} from './services/authentication.service';
// Product
import {ProductComponent} from './pages/product/product.component';
import {ProductService} from './services/product.service';
import {ProductTableComponent} from './pages/product/product-table.component';
import {ProductPanelComponent} from './pages/product/product-panel.component';
import {ProductDetailComponent} from './pages/product/product-detail.component';
// Version
import {VersionComponent} from './pages/version/version.component';
import {VersionService} from './services/version.service';
import {VersionTableComponent} from './pages/version/version-table.component';
import {VersionDetailComponent} from './pages/version/version-detail.component';
import {VersionGraphComponent} from './pages/version/graph/version-graph.component';
// Update
import {UpdateComponent} from './pages/update/update.component';
import {UpdateService} from './services/update.service';
import {UpdateTableComponent} from './pages/update/update-table.component';
import {UpdateDetailComponent} from './pages/update/update-detail.component';
import {UpdateCreatePanelComponent} from './pages/update/create/update-create-panel.component';
import {UpdateUploadComponent} from './pages/update/update-upload.component';
import {UploadService} from './services/upload.service';
// User
import {UserComponent} from './pages/user_management/user.component';
import {UserService} from './services/user.service';
import {UserDetailComponent} from './pages/user_management/user-detail-component';
import {CurrentUserService} from './services/current-user.service';
import {UserTableComponent} from './pages/user_management/user-table.component';
import {UserActivateComponent} from './pages/user_settings/user-activate.component';
import {AccountService} from './services/account.service';
import {PasswordResetFinishComponent} from './components/password-reset/password-reset.component';
import {PasswordStrengthBarComponent} from './components/password-reset/password-strength-bar.component';
import {UserSettingsComponent} from './pages/user_settings/user-settings.component';
import {UserPasswordComponent} from './pages/user_settings/user-password.component';
import {UserForgotPasswordComponent} from './pages/user_settings/user-forgot-password.component';
import {UserResetPasswordComponent} from './pages/user_settings/user-reset-password.component';
// Group
import {GroupComponent} from './pages/group_management/group.component';
import {GroupService} from './services/group.service';
import {GroupDetailComponent} from './pages/group_management/group-detail.component';
import {GroupTableComponent} from './pages/group_management/group-table.component';
// Lang
import {LangService} from './services/lang.service';
// Statistics
import {StatisticComponent} from './pages/statistic/statistic.component';
import {StatisticPanelComponent} from './pages/statistic/statistic-panel.component';
import {StatisticParkStateComponent} from './pages/statistic/graphs/statistic-park-state.component';
import {StatisticRequestsComponent} from './pages/statistic/graphs/statistic-requests.component';
import {StatisticFilterComponent} from './pages/statistic/filter/statistic-filter.component';
import {StatisticService} from './services/statistic.service';
// Utils
import {SelectItemsComponent} from './components/util/select-items.component';
import {LoaderOverlayComponent} from './components/util/loader-overlay.component';
import {ShortenStringPipe} from './pipes/shorten-string.pipe';
import {CheckArrayLengthPipe} from './pipes/check-array-length.pipe';
import {SizePipe} from './pipes/size.pipe';
import {DisplayListComponent} from './components/list/display-list.component';
import {DescriptionComponent} from './components/description/description.component';
import {InputCounterComponent} from './components/util/input-counter.component';
// Modal
import {SelectItemsByTableModalComponent} from './components/modal/select-items/select-items-by-table-modal.component';
import {ConfirmModalComponent} from './components/modal/confirm/confirm-modal.component';
// Services
import {StateStorageService} from './services/state-storage.service';
import {ToasterService} from './services/toaster.service';
/* NGX */
import {Ng2Webstorage} from 'ngx-webstorage';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {
  AccordionModule,
  BsDatepickerModule,
  BsDropdownModule,
  CollapseModule,
  ModalModule,
  PaginationModule,
  TabsModule
} from 'ngx-bootstrap';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {ToastrModule} from 'ngx-toastr';
//import {NgProgressInterceptor} from 'ngx-progressbar';
import { NgProgressModule } from '@ngx-progressbar/core';
import { NgProgressHttpModule } from '@ngx-progressbar/http';
import {Ng2TableModule} from 'ngx-datatable';
import {NgxGraphModule} from '@swimlane/ngx-graph';
import {NgxChartsModule} from '@swimlane/ngx-charts';
/* FONT AWESOME */
import {AngularFontAwesomeModule} from 'angular-font-awesome';
/* NG-SELECT */
import {NgSelectModule} from '@ng-select/ng-select';
/* NGX-UPLOADX */
import {UploadxModule} from './components/ngx-uploadx/uploadx.module';
import {UploadxService} from './components/ngx-uploadx/uploadx.service';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    EditBarComponent,
    AuthenticationComponent,
    ProductComponent,
    ProductTableComponent,
    ProductPanelComponent,
    ProductDetailComponent,
    VersionComponent,
    VersionTableComponent,
    VersionDetailComponent,
    VersionGraphComponent,
    UpdateComponent,
    UpdateTableComponent,
    UpdateDetailComponent,
    UpdateCreatePanelComponent,
    UpdateUploadComponent,
    GroupComponent,
    GroupDetailComponent,
    GroupTableComponent,
    UserComponent,
    UserDetailComponent,
    UserTableComponent,
    UserActivateComponent,
    PasswordResetFinishComponent,
    PasswordStrengthBarComponent,
    UserSettingsComponent,
    UserPasswordComponent,
    UserForgotPasswordComponent,
    UserResetPasswordComponent,
    StatisticComponent,
    StatisticPanelComponent,
    StatisticParkStateComponent,
    StatisticRequestsComponent,
    StatisticFilterComponent,
    SelectItemsByTableModalComponent,
    ConfirmModalComponent,
    SelectItemsComponent,
    LoaderOverlayComponent,
    ShortenStringPipe,
    CheckArrayLengthPipe,
    SizePipe,
    DisplayListComponent,
    DescriptionComponent,
    InputCounterComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes, {useHash: true}),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2Webstorage,
    NgProgressModule.forRoot(),
    NgProgressHttpModule,
    Ng2TableModule,
    PaginationModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    CollapseModule.forRoot(),
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    BsDatepickerModule.forRoot(),
    AngularFontAwesomeModule,
    ToastrModule.forRoot({
      positionClass: 'toast-bottom-right',
      progressBar: true
    }),
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    NgSelectModule,
    NgxGraphModule,
    NgxChartsModule,
    UploadxModule,
  ],
  providers: [
    AuthenticationService,
    AccountService,
    ProductService,
    VersionService,
    UpdateService,
    UploadService,
    StateStorageService,
    CurrentUserService,
    UserService,
    GroupService,
    LangService,
    StatisticService,
    ToasterService,
    UploadxService,
    DatePipe,
    ShortenStringPipe,
    CheckArrayLengthPipe,
    SizePipe,
    ConfirmDeactivateInterceptor,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
 //   {
 //     provide: HTTP_INTERCEPTORS,
 //     useClass: NgProgressInterceptor,
  //    multi: true
   // },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpResponseInterceptor,
      multi: true
    }
  ],
  entryComponents: [
    SelectItemsByTableModalComponent,
    ConfirmModalComponent,
    GroupTableComponent,
    GroupDetailComponent,
    UserTableComponent,
    ProductTableComponent,
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
