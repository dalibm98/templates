import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-edit-bar',
  templateUrl: './edit-bar.component.html'
})
export class EditBarComponent {

  @Input() selectedElement;
  @Input() readonly;

  @Input() editDisabled = false;
  @Input() saveDisabled;
  @Input() newDisplayed = true;
  @Input() deleteDisplayed = true;

  @Output() editClicked: EventEmitter<void> = new EventEmitter();
  @Output() saveClicked: EventEmitter<void> = new EventEmitter();
  @Output() cancelClicked: EventEmitter<void> = new EventEmitter();
  @Output() newClicked: EventEmitter<void> = new EventEmitter();
  @Output() deleteClicked: EventEmitter<void> = new EventEmitter();

  edit() {
    this.editClicked.emit();
  }

  save() {
    this.saveClicked.emit();
  }

  cancel() {
    this.cancelClicked.emit();
  }

  new() {
    this.newClicked.emit();
  }

  delete() {
    this.deleteClicked.emit();
  }
}
