import {Component, Input} from '@angular/core';
import {Router} from '@angular/router';
import {ProductService} from '../../../services/product.service';
import {AuthenticationService} from '../../../services/authentication.service';
import {CurrentUserService} from '../../../services/current-user.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar-component.html',
  styleUrls: ['./navbar-component.scss']
})
export class NavbarComponent {

  private _isLoggedIn;
  isCollapsed = true;

  constructor(private productService: ProductService,
              private authService: AuthenticationService,
              private router: Router,
              protected currentUserService: CurrentUserService) {
  }

  @Input()
  set isLoggedIn(isLoggedIn: boolean) {
    this._isLoggedIn = isLoggedIn;
    if (isLoggedIn) {
      this.currentUserService.getUser().then(() => {
      }, () => {
        this._isLoggedIn = false;
      });
    }
  }

  get isLoggedIn(): boolean {
    return this._isLoggedIn;
  }

  logout(): void {
    this.authService.logout().then(() => {
      this.currentUserService.clear();
      this.router.navigate(['login']);
    });
  }
}
