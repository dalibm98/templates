import {Component, EventEmitter, Input, OnChanges, OnInit, ElementRef, ViewChild} from '@angular/core';
import {LangDto} from '../../model/lang/lang-dto';
import {of} from 'rxjs/internal/observable/of';
import {LangService} from '../../services/lang.service';
import {SimpleChanges} from '@angular/core/src/metadata/lifecycle_hooks';
import {debounceTime, switchMap} from 'rxjs/operators';
import {NgSelectComponent} from '@ng-select/ng-select';

@Component({
  selector: 'app-description',
  templateUrl: './description.component.html',
})
export class DescriptionComponent implements OnInit, OnChanges {

  @ViewChild('descriptionLangSelect') descriptionLangSelect: NgSelectComponent;

  @Input() readonly: boolean;
  @Input() titleArray = [];
  @Input() descriptionArray = [];

  typeaheadLanguages = new EventEmitter<string>();
  foundLanguages: LangDto[] = [];
  definedLangDesc: string[] = [];
  currentSelectedLang: string;
  searchLangTerm: string;

  constructor(private langService: LangService) {
  }

  public ngOnInit() {
    this.typeaheadLanguages
      .pipe(
        debounceTime(300),
        switchMap(term => {
          this.searchLangTerm = term;
          return term ? this.langService.findByLangOrCode(term) : of([]);
        })
      ).subscribe(items => {
        this.foundLanguages = items.filter(lang => this.definedLangDesc.indexOf(lang.language) === -1);
      }, (err) => {
        console.log(err);
        this.foundLanguages = [];
      });
  }

  public ngOnChanges(changes: SimpleChanges) {
    this.definedLangDesc = [];
    for (const lang of Object.keys(this.titleArray)) {
      this.definedLangDesc.push(lang);
    }
    if (this.definedLangDesc.length > 0) {
      this.currentSelectedLang = this.definedLangDesc[0];
    }
  }

  selectDescription(lang: string) {
    this.currentSelectedLang = lang;
  }

  addDescription(newDescriptionLang) {
    this.descriptionLangSelect.clearModel();
    const lang = newDescriptionLang.language;
    this.definedLangDesc.push(lang);
    this.titleArray[lang] = '';
    this.descriptionArray[lang] = '';
    this.foundLanguages = [];
    this.selectDescription(lang);
    this.searchLangTerm = null;
  }

  deleteDescription(deletedLang: string) {
    const index = this.definedLangDesc.indexOf(deletedLang, 0);
    if (index > -1) {
      this.definedLangDesc.splice(index, 1);
      delete this.titleArray[deletedLang];
      delete this.descriptionArray[deletedLang];
      if (this.currentSelectedLang === deletedLang && this.definedLangDesc.length > 0) {
        this.currentSelectedLang = this.definedLangDesc[index - 1 > 0 ? index - 1 : 0];
      }
    }
  }
}
