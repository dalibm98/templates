import {EventEmitter, Input, Output} from '@angular/core';
import {AbstractCrudService} from '../../services/crud/abstract-crud.service';
import {BsModalService} from 'ngx-bootstrap/modal';
import {ModalOptions} from 'ngx-bootstrap';
import {ConfirmModalComponent} from '../modal/confirm/confirm-modal.component';
import {IModel} from '../../model/imodel';

export abstract class AbstractDetailComponent<M extends IModel, S extends AbstractCrudService<M>> {

  private _uid: string;
  readonly = true;

  originDetail: M;
  currentDetail: M;
  isInModal = false;

  @Output() newEvent: EventEmitter<void> = new EventEmitter();
  @Output() updateEvent: EventEmitter<any> = new EventEmitter();
  @Output() deleteEvent: EventEmitter<void> = new EventEmitter();

  constructor(protected modelClass: any, protected service: S, protected modalService: BsModalService) {
  }

  @Input()
  set uid(uid: string) {
    if (!uid) {
      return;
    }
    this.readonly = true;
    this._uid = uid;
    this.refreshDetail();
  }

  refreshDetail() {
    if (this._uid) {
      this.service.getByUid(this._uid).then(res => {
        this.originDetail = res;
        this.initCurrentDetail();
      });
    }
  }

  // noinspection JSUnusedLocalSymbols
  edit(event) {
    this.preEdit();
    this.readonly = false;
  }

  // noinspection JSUnusedLocalSymbols
  save(event) {
    this.preSave();
    this.service.save(this.currentDetail).then(res => {
      this.originDetail = res;
      this.initCurrentDetail();
      this.readonly = true;
      this.updateEvent.emit(this.originDetail);
      this.postSave();
    });
  }

  // noinspection JSUnusedLocalSymbols
  cancel(event) {
    if (this.originDetail) {
      this.initCurrentDetail();
    } else {
      this.currentDetail = null;
    }

    this.readonly = true;
    this.postCancel();
  }

  // noinspection JSUnusedLocalSymbols
  new(event) {
    this.preNew();
    this.originDetail = null;
    this.currentDetail = new this.modelClass.prototype.constructor;
    this.readonly = false;
    this.newEvent.emit();
    this.postNew();
  }

  // noinspection JSUnusedLocalSymbols
  delete(event) {
    const modalOptions = new ModalOptions();
    modalOptions.initialState = {
      'confirmMessageKey': 'modal.delete.confirm',
      'confirmMessageValue': this.modelClass.prototype.getDescription.apply(this.originDetail),
      'confirmIcon': 'trash',
      'confirmButton': 'button.delete'
    };
    const bsModalRef = this.modalService.show(ConfirmModalComponent, modalOptions);
    bsModalRef.content.onClose.subscribe(isDelete => {
      if (isDelete) {
        this.preDelete();
        this.service.delete(this.originDetail).then(() => {
          this.originDetail = null;
          this.currentDetail = null;
          this.deleteEvent.emit();
        });
      }
    });
  }

  protected abstract initCurrentDetail();

  protected preEdit() {
  }

  protected preSave() {
  }

  protected postSave() {
  }

  protected postCancel() {
  }

  protected preNew() {
  }

  protected postNew() {
  }

  protected preDelete() {
  }
}
