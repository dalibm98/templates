import {Component, HostBinding, Input} from '@angular/core';

@Component({
  selector: 'app-display-list',
  templateUrl: './display-list.component.html',
})
export class DisplayListComponent {
  @HostBinding('class') cssClass = 'form-control form-control-min-height form-control-max-height overflow d-flex flex-row flex-wrap align-items-center';
  @HostBinding('style.cursor') cssStyle = 'default';
  @HostBinding('attr.disabled') css2Style = true;

  @Input() bindLabel: string;
  @Input() bindTooltip: string;
  @Input() listToDisplay = [];
  @Input() placeholder: string;
}
