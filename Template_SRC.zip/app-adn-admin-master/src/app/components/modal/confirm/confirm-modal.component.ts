import {Component, OnInit} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';
import {Subject} from 'rxjs';
import {TranslateService} from '@ngx-translate/core';

@Component({
  templateUrl: './confirm-modal.component.html'
})
export class ConfirmModalComponent implements OnInit {

  public onClose: Subject<any>;

  confirmMessageKey: string | Array<string> ;
  confirmMessageValue: string;
  confirmIcon = 'check';
  confirmButton = 'button.yes';
  confirmMessages = [];
  confirmCancelIcon = 'ban';
  confirmCancelButton = 'button.cancel';

  constructor(private _bsModalRef: BsModalRef, private translate: TranslateService) {
  }

  public ngOnInit(): void {
    this.onClose = new Subject();
    if (this.confirmMessageValue) {
      if (this.confirmMessageKey instanceof Array) {
        for (let i = 0; i < this.confirmMessageKey.length; i++) {
          this.addConfirmMessageWithKey(this.confirmMessageKey[i], this.confirmMessageValue[i]);
        }
      } else {
        this.addConfirmMessageWithKey(this.confirmMessageKey, this.confirmMessageValue);
      }
    } else {
      if (this.confirmMessageKey instanceof Array) {
        this.confirmMessageKey.forEach(confirmMessage => {
          this.addConfirmMessage(confirmMessage);
        });
      } else {
        this.addConfirmMessage(this.confirmMessageKey);
      }
    }
  }

  private addConfirmMessage(confirmMessage: string) {
    this.translate.get(confirmMessage).subscribe(msg => {
      this.confirmMessages.push(msg);
    });
  }

  private addConfirmMessageWithKey(messageKey: string, messageValue: string) {
    if (messageValue) {
      this.translate.get(messageValue).subscribe(value => {
        this.translate.get(messageKey, {value: value}).subscribe(msg => {
          this.confirmMessages.push(msg);
        });
      });
    } else {
      this.addConfirmMessage(messageKey);
    }
  }

  public onConfirm(): void {
    this.onClose.next(true);
    this._bsModalRef.hide();
  }

  public onCancel(): void {
    this.onClose.next(false);
    this._bsModalRef.hide();
  }
}
