import {
  Component, ComponentFactoryResolver, ComponentRef, Injector, OnDestroy, OnInit, Type, ViewChild,
  ViewContainerRef
} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';
import {Subject} from 'rxjs';

import {AbstractCrudService} from '../../../services/crud/abstract-crud.service';
import {AbstractTableComponent} from '../../table/abstract-table.component';
import {IModel} from '../../../model/imodel';
import {AbstractDetailComponent} from '../../detail/abstract-detail.component';

@Component({
  templateUrl: './select-items-by-table-modal.component.html'
})
export class SelectItemsByTableModalComponent
    <M extends IModel, C extends AbstractDetailComponent<M, S>, S extends AbstractCrudService<M>, T extends AbstractTableComponent<M, S>>
  implements OnInit, OnDestroy {

  public onClose: Subject<any>;

  @ViewChild('tableViewRef', {read: ViewContainerRef}) tableComponentRef: ViewContainerRef;
  private tableComponent: ComponentRef<T>;
  @ViewChild('createViewRef', {read: ViewContainerRef}) createViewRef: ViewContainerRef;

  inputForceList = [];
  inputSelectedList = [];
  inputBindLabel: string;
  inputSelectPlaceholder: string;
  inputTableComponentToCreate: Type<T>;
  inputCreatePlaceholder: string;
  inputCreateButtonLabel = 'button.create';

  inputIsCreateNeeded: boolean;
  inputCreateComponentToCreate: Type<C>;
  inputCreateElementService: Type<S>;
  inputCreateElementClass: any;
  isCreate = false;
  createModel: M;
  createService: S;

  outputSelectedList = [];

  constructor(private _bsModalRef: BsModalRef,
              private factoryResolver: ComponentFactoryResolver,
              private injector: Injector) {
  }

  public ngOnInit(): void {
    this.onClose = new Subject();
    if (this.inputIsCreateNeeded) {
      this.createService = this.injector.get(this.inputCreateElementService);
    }

    this.outputSelectedList = JSON.parse(JSON.stringify(this.inputSelectedList));
    const factory = this.factoryResolver.resolveComponentFactory(this.inputTableComponentToCreate);
    this.tableComponent = factory.create(this.tableComponentRef.parentInjector);
    this.tableComponent.instance.forceItemList = this.inputForceList;
    this.tableComponent.instance.multipleSelect = true;
    this.tableComponent.instance.tableSelectedItems = this.outputSelectedList;
    this.tableComponent.instance.multiCellClickEvent.subscribe(selectItems => {
      this.outputSelectedList = selectItems.slice(0, selectItems.length);
    });
    this.tableComponentRef.insert(this.tableComponent.hostView);
  }

  public ngOnDestroy(): void {
    this.tableComponent.instance.multiCellClickEvent.unsubscribe();
  }

  public onConfirm(): void {
    this.onClose.next(this.outputSelectedList);
    this._bsModalRef.hide();
  }

  public onCancel(): void {
    this.onClose.next(null);
    this._bsModalRef.hide();
  }

  showCreate() {
    if (!this.isCreate) {
      this.isCreate = true;
      const factory = this.factoryResolver.resolveComponentFactory(this.inputCreateComponentToCreate);
      const component = factory.create(this.createViewRef.parentInjector);
      this.createModel = Object.create(this.inputCreateElementClass.prototype);
      this.createModel = this.createModel.constructor.apply(this.createModel);
      component.instance.currentDetail = this.createModel;
      component.instance.isInModal = true;
      component.instance.edit(null);
      this.createViewRef.insert(component.hostView);
    }
  }

  createElement() {
    this.createService.save(this.createModel).then(res => {
      this.outputSelectedList.push(res);
      this.outputSelectedList = this.outputSelectedList.slice(0, this.outputSelectedList.length);
      this.tableComponent.instance.updateTable();
      this.cancelCreateElement();
    });
  }

  cancelCreateElement() {
    this.createViewRef.clear();
    this.isCreate = false;
  }
}
