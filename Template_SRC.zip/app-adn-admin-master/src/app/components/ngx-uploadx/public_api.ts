export * from './uploadx.module';
export {
  UploadxOptions,
  UploadxControlEvent,
  UploadState,
  UploadItem
} from './interfaces';
export { UploadxService } from './uploadx.service';
