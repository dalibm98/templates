import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {AccountService} from '../../services/account.service';
import {KeyAndPassword} from '../../model/account/key-and-password';

@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html'
})
export class PasswordResetFinishComponent implements OnInit {
  @Input() resetKey: string;

  @Output() passwordChanged: EventEmitter<boolean> = new EventEmitter();

  confirmPassword: string;
  doNotMatch: string;
  error: string;
  resetAccount: any;
  success: string;

  constructor(private accountService: AccountService) {
  }

  ngOnInit() {
    this.resetAccount = {};
  }

  finishReset() {
    this.doNotMatch = null;
    this.error = null;
    this.success = null;
    if (this.resetAccount.password !== this.confirmPassword) {
      this.doNotMatch = 'ERROR';
    } else {
      let newPassword;
      if (this.resetKey) {
        newPassword = new KeyAndPassword();
        newPassword.key = this.resetKey;
        newPassword.newPassword = this.resetAccount.password;
      } else {
        newPassword = this.resetAccount.password;
      }

      this.accountService.savePassword(newPassword).then(() => {
        this.success = 'OK';
        this.passwordChanged.emit(true);
      }, () => {
        this.success = null;
        this.error = 'ERROR';
        this.passwordChanged.emit(false);
      });
    }
  }

}
