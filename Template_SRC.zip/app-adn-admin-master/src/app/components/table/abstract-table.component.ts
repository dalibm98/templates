import {EventEmitter, HostBinding, Input, OnInit, Output, ViewChild} from '@angular/core';
import {AbstractCrudWithSearchService} from '../../services/crud/abstract-crud-with-search.service';
import {SearchDto} from '../../model/search/search-dto';
import {FormControl} from '@angular/forms';


import {Observable} from 'rxjs';
import {AbstractCrudService} from '../../services/crud/abstract-crud.service';
import {IModel} from '../../model/imodel';
import {debounceTime, distinctUntilChanged} from 'rxjs/operators';

export abstract class AbstractTableComponent<M extends IModel, S extends AbstractCrudService<M>> implements OnInit {
  @HostBinding('class') cssClass = 'd-flex flex-column col';

  @ViewChild('tableContainer') tableContainer: any;

  // Force Table rows
  @Input() forceItemList: M[] = [];
  @Input() tableSelectedItems: M[] = [];
  @Input() multipleSelect = false;

  public rows: Array<any> = [];

  public page = 1;
  public totalPages = 1;
  public itemsPerPage = 10;
  public numPages = 1;
  public length = 0;

  public config: {
    paging?: boolean,
    sorting?: {
      columns: any
    },
    filtering?: {
      filterString: string,
      columnName: string
    },
    className: string | Array<string>
  };

  columns = [];
  protected filterPlaceholder: string;

  searchActivated = false;
  searchField: FormControl;

  @Output() cellClickEvent: EventEmitter<M> = new EventEmitter<M>();
  @Output() multiCellClickEvent: EventEmitter<M[]> = new EventEmitter<M[]>();

  protected constructor(public service: S) {
    this.config = {
      paging: true,
      sorting: {columns: null},
      filtering: {filterString: '', columnName: ''},
      className: ['table-hover']
    };
    if (service instanceof AbstractCrudWithSearchService) {
      this.searchActivated = true;
    }
  }

  public ngOnInit(): void {
    // SearchField
    this.searchField = new FormControl();
    this.searchField.valueChanges.pipe(
      debounceTime(400),
      distinctUntilChanged()
    ).subscribe(term => {
        this.config.filtering.filterString = term;
        this.onChangeTable(this.config);
      });

    this.initTableColumns().subscribe(() => {
      }, () => {
      }, () => {
        this.initFilterPlaceholder();
        this.config.sorting = {columns: this.columns};
        this.onChangeTable(this.config);
      }
    );
  }

  protected abstract initTableColumns(): Observable<void>;

  protected abstract initFilterPlaceholder(): void;

  protected abstract reduceData(rows: Array<M>): Array<any>;

  protected expandData(rows: Array<any>): Array<M> {
    return rows;
  }

  public onChangeTable(config: any, page: any = {page: this.page, itemsPerPage: this.itemsPerPage}): any {
    if (config.filtering) {
      Object.assign(this.config.filtering, config.filtering);
    }

    if (config.sorting) {
      Object.assign(this.config.sorting, config.sorting);
    }

    const search = new SearchDto(page.itemsPerPage, page.page - 1, config.filtering.filterString);
    config.sorting.columns.forEach(column => {
      if (column.sort) {
        search.sort = {column: column.name, direction: column.sort.toUpperCase()};
      }
    });

    if (this.service instanceof AbstractCrudWithSearchService) {
      this.findBySearch(search)
        .then(() => setTimeout(() => this.highlightSelectedRow(this.tableSelectedItems), 10));
    } else {
      this.getAll()
        .then(() => setTimeout(() => this.highlightSelectedRow(this.tableSelectedItems), 10));
    }
  }

  protected findBySearch(search: SearchDto): Promise<any> {
    if (this.forceItemList.length !== 0) {
      return new Promise<any>((res) => {
        this.length = this.forceItemList.length;
        this.totalPages = 1;
        this.rows = this.reduceData(this.forceItemList);
        res();
      });
    } else {
      if (this.service instanceof AbstractCrudWithSearchService) {
        return this.service.findBySearch(search).then(pageResult => {
          this.length = pageResult.totalElements;
          this.totalPages = pageResult.totalPages;
          this.rows = this.reduceData(pageResult.content);
        });
      } else {
        throw new Error('findBySearch called with wrong service class ' + this.service.constructor.name);
      }
    }
  }

  protected getAll(): Promise<any> {
    if (this.forceItemList.length !== 0) {
      return new Promise<any>((res) => {
        this.length = this.forceItemList.length;
        this.rows = this.reduceData(this.forceItemList);
        res();
      });
    } else {
      return this.service.getAll().then(rows => {
        this.length = rows.length;
        this.rows = this.reduceData(rows);
      });
    }
  }

  public onCellClick(data: any): any {
    const row = this.expandData([data.row])[0];
    if (!this.multipleSelect) {
      this.tableSelectedItems = [row];
      this.cellClickEvent.emit(row);
    } else {
      const selectedItem = this.tableSelectedItems.find(item => item.uid === row.uid);
      const isRowInSelectItemsIndex = this.tableSelectedItems.indexOf(selectedItem);
      if (isRowInSelectItemsIndex !== -1) {
        this.tableSelectedItems.splice(isRowInSelectItemsIndex, 1);
      } else {
        this.tableSelectedItems.push(row);
      }
      this.multiCellClickEvent.emit(this.tableSelectedItems);
    }
    this.highlightSelectedRow(this.tableSelectedItems);
  }

  public highlightSelectedRow(data: any): void {
    const trs = this.tableContainer.nativeElement.children[0].children[0].children[1].children;
    const rowNumbers: number[] = [];
    if (!this.multipleSelect) {
      rowNumbers.push(data && data[0] ? this.rows.findIndex(el => el.uid === data[0].uid) : -1);
      if (rowNumbers[0] > -1 && rowNumbers[0] < trs.length) { // Return if current row is selected row
        if (trs[rowNumbers[0]].className === 'active') {
          return;
        }
      }
    } else {
      for (const elementData of data) {
        rowNumbers.push(this.rows.findIndex(el => el.uid === elementData.uid));
      }
    }

    for (let i = 0; i < trs.length; i++) {
      trs[i].className = (rowNumbers.indexOf(i) !== -1) ? 'active' : '';
    }
  }

  public updateTable() {
    this.onChangeTable(this.config);
  }
}
