import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-input-counter',
  template: '<small class="form-text text-muted" *ngIf="_element">' +
  '{{_element.value.length}} / {{maxValue}} {{\'global.characters\' | translate}}' +
  '</small>'
})
export class InputCounterComponent {
  @Input() maxValue: number;

  @Input()
  set elementRef(element: HTMLElement) {
    if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
      this._element = element;
      element.maxLength = this.maxValue;
    } else if (!!element) {
      throw Error('[APP-INPUT-COUNTER] Wrong type of element. Needed HTMLInputElement or HTMLTextAreaElement');
    }
  }

  _element: HTMLInputElement | HTMLTextAreaElement;
}
