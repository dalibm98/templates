import {Component, OnInit} from '@angular/core';
import {NgProgress, NgProgressRef} from '@ngx-progressbar/core';

// import { NgProgress } from 'ngx-progressbar';

@Component({
  selector: 'app-loader-overlay',
  template: `
    <ng-progress [color]="'#bdd24'" [spinner]="false"></ng-progress>
    <div *ngIf="progressRef.state$ | async; let state">
      <div *ngIf="state.active && state.value !== 0" class="loader-overlay" id="loader_overlay"></div>
    </div>`
})
export class LoaderOverlayComponent {
  progressRef: NgProgressRef;

  constructor(private progress: NgProgress) {
    this.progressRef = this.progress.ref();
  }

}
