import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-select-items',
  templateUrl: './select-items.component.html'
})
export class SelectItemsComponent implements OnInit {

  @Output() selectEvent: EventEmitter<any> = new EventEmitter();
  @Output() cancelEvent: EventEmitter<void> = new EventEmitter();

  @Input() inputDefaultList: Array<any>;
  @Input() inputSelectedList = [];
  @Input() inputAttrId: string;
  @Input() inputAttrDesc: string;
  @Input() inputAddButtonLabel = 'button.add';

  @Input()
  set inputAddElement(inputAddElement: any) {
    if (!inputAddElement) {
      return;
    }
    this.outputSelectedList.push(inputAddElement);
  }

  currAttrs: Array<string>;

  outputSelectedList = [];

  constructor() {
  }

  public ngOnInit(): void {
    this.currAttrs = this.inputAttrDesc.split(' ');
    this.outputSelectedList = this.outputSelectedList.concat(this.inputSelectedList);
  }

  public select(): void {
    this.selectEvent.emit(this.outputSelectedList);
  }

  public cancel(): void {
    this.cancelEvent.emit();
  }

  addSelectedItem(el: any) {
    const index = this.outputSelectedList.indexOf(el);
    if (index !== -1) {
      this.outputSelectedList.splice(index, 1);
    } else {
      this.outputSelectedList.push(el);
    }
  }

  isElementInInputList(el: any): boolean {
    return this.inputSelectedList.map(element => element[this.inputAttrId]).indexOf(el[this.inputAttrId]) !== -1;
  }

  isElementInOutputList(el: any): boolean {
    return this.outputSelectedList.map(element => element[this.inputAttrId]).indexOf(el[this.inputAttrId]) !== -1;
  }

}
