import {throwError as observableThrowError, Observable} from 'rxjs';
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {LocalStorageService, SessionStorageService} from 'ngx-webstorage';
import {environment} from '../../environments/environment';
import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {StateStorageService} from '../services/state-storage.service';
import {EMPTY} from 'rxjs/internal/observable/empty';
import {tap} from 'rxjs/operators';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  private authenticationToken = 'authenticationToken';

  constructor(private localStorage: LocalStorageService,
              private sessionStorage: SessionStorageService,
              private stateStorage: StateStorageService,
              private router: Router) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = this.localStorage.retrieve(this.authenticationToken) || this.sessionStorage.retrieve(this.authenticationToken);
    if (!!token) {
      req = req.clone({
        setHeaders: {
          Authorization: 'Bearer ' + token
        }
      });
    } else {
      // Block request if token not present
      // and request url doesn't points to a public API address
      // and request url doesn't points to an app resource
      if (!req.url.startsWith(environment.serverPublicUrl) && !req.url.startsWith('/')) {
        return EMPTY;
      }
    }
    return next.handle(req).pipe(
      tap(() => {
      }, err => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 401) {
            this.localStorage.clear(this.authenticationToken);
            this.sessionStorage.clear(this.authenticationToken);
            if (!/^\/login/.test(this.router.url) && !this.stateStorage.isUrl()) {
              this.stateStorage.storeUrl(this.router.url); // TODO URL is wrong, get current path and options
            }
            this.router.navigate(['/login', {'reason': err.statusText.toLowerCase()}]);
          } else if (err.status === 403) {
            this.router.navigate(['/']);
          }
          return observableThrowError(err);
        }
      }));
  }

}
