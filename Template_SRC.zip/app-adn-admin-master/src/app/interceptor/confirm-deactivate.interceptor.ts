import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';

@Injectable()
export class ConfirmDeactivateInterceptor implements CanDeactivate<ConfirmDeactivateComponent> {

  canDeactivate(target) {
    if (target.shouldNotDeactivate()) {
      const isDeactivate = window.confirm(target.getConfirmDeactivateMessage());
      if (isDeactivate) {
        target.deactivateAction();
      } else {
        target.continueAction();
      }
      return isDeactivate;
    }
    return true;
  }

}

export interface ConfirmDeactivateComponent {
  shouldNotDeactivate(): boolean;
  getConfirmDeactivateMessage(): string;
  deactivateAction();
  continueAction();
}
