import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse} from '@angular/common/http';
import {ToasterService} from '../services/toaster.service';
import {Injectable, Injector} from '@angular/core';
import {Observable} from 'rxjs';
import {tap} from 'rxjs/operators';


@Injectable()
export class HttpResponseInterceptor implements HttpInterceptor {

  private static ALERT_HEADER_MESSAGE = 'X-adnAdmin-message';
  private static ALERT_HEADER_PARAM = 'X-adnAdmin-params';

  private toaster: ToasterService;

  constructor(private inj: Injector) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (!this.toaster) {
      this.toaster = this.inj.get(ToasterService);
    }

    return next.handle(req).pipe(
      tap((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          const respMsg = event.headers.get(HttpResponseInterceptor.ALERT_HEADER_MESSAGE);
          if (respMsg) {
            this.toaster.success(respMsg);
          }
        }
      }, (err: any) => {
        if (err instanceof HttpErrorResponse) {
          const errMsg = err.headers.get(HttpResponseInterceptor.ALERT_HEADER_MESSAGE);
          const errParam = err.headers.get(HttpResponseInterceptor.ALERT_HEADER_PARAM);
          if (errMsg) {
            if (errParam) {
              this.toaster.errorWithParam(errMsg.split(','), errParam.split(','));
            } else {
              this.toaster.error(errMsg.split(','));
            }
          }
        }
      }));
  }

}
