export abstract class AbstractFollowUpDto {
  createdDate: number;
  createdBy: string;
  modifiedDate: number;
  modifiedBy: string;
}
