export class KeyAndPassword {
  key: string;
  newPassword: string;
}
