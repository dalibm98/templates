import {IModel} from '../imodel';

export class GroupDto implements IModel {
  uid: string;
  name: string;
  comment: string;
  productRightDtoList: Array<SimpleProductRightDto>;

  constructor() {
    this.productRightDtoList = [];
  }

  public getDescription() {
    return this.name;
  }
}

export class SimpleProductRightDto {
  /**
   * Product Name
   */
  name: string;
  /**
   * Product UID
   */
  uid: string;
  productRightUid: string;
  productRight: string;
}
