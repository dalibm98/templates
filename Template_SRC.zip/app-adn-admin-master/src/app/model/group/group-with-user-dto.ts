import {GroupDto} from './group-dto';
import {UserDto} from '../user/user-dto';

export class GroupWithUserDto extends GroupDto {
  users: Array<UserDto>;

  constructor() {
    super();
    this.users = [];
  }

  public getDescription() {
    return super.getDescription();
  }
}
