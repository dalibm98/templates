export interface IModel {
  uid: string;

  getDescription(): string;
}
