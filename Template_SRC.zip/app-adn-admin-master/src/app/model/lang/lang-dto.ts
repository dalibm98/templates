import {IModel} from '../imodel';

export class LangDto implements IModel {
  id: number;
  uid: string;
  code: string;
  language: string;

  public getDescription() {
    return this.language + ' [' + this.code + ']';
  }
}
