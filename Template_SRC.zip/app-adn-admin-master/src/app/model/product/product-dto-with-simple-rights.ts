import {IModel} from '../imodel';

export class ProductDtoWithSimpleRights implements IModel {
  uid: string;
  name: string;
  comment: string;
  code: string;
  icon: any;
  right: string;

  getDescription(): string {
    return this.name + ' ' + this.comment;
  }
}
