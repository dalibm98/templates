import {IModel} from '../imodel';
import {UpdateDto} from '../update/update-dto';
import {VersionDto} from '../version/version-dto';

export class ProductDto implements IModel {
  id: number;
  uid: string;
  name: string;
  comment: string;
  code: string;
  icon: any;
  versions: Array<VersionDto>;
  updates: Array<UpdateDto>;
  profiles: string[];

  constructor() {
    this.versions = [];
    this.updates = [];
  }

  getDescription() {
    return this.name + ' ' + this.comment;
  }
}
