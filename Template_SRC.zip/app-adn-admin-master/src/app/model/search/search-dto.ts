export class SearchDto {
  searchString: string;
  pageSize: number;
  pageNumber: number;
  sort: Sort;

  constructor(pageSize: number, pageNumber: number, searchString?: string) {
    this.pageSize = pageSize;
    this.pageNumber = pageNumber;
    this.searchString = searchString;
  }
}

export class Sort {
  column: string;
  direction: string;
}
