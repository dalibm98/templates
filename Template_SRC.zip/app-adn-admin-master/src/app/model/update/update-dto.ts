import {AbstractFollowUpDto} from '../abstract-follow-up-dto';
import {IModel} from '../imodel';

export class UpdateDto extends AbstractFollowUpDto implements IModel {
  id: number;
  uid: string;
  name: string;
  titles: any;
  descriptions: any;
  comment: string;
  status: string;
  code: string;
  productUid: string;
  blocking: boolean;
  majorUpdate: boolean;
  productProfiles: string[];

  getDescription() {
    return this.name;
  }
}
