import {UpdateWithAssociatedVersionsDto} from './update-with-associated-versions-dto';

export class UpdateFullDto extends UpdateWithAssociatedVersionsDto {
  updateFiles: UpdateFileDto[];
}

export class UpdateFileDto {
  uid: string;
  checksum: string;
  checksumType: string;
  size: number;
  uncompressedSize: number;
  name: string;
  profiles: string[];
}
