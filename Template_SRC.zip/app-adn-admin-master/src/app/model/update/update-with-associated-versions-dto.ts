import {UpdateDto} from './update-dto';
import {VersionDto} from '../version/version-dto';

export class UpdateWithAssociatedVersionsDto extends UpdateDto {
  linkedVersion: VersionDto;
  appliedVersions: Array<VersionDto>;
}
