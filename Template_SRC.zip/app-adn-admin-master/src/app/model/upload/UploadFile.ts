import {UploadState} from '../../components/ngx-uploadx/interfaces';

export class UploadFile {
  uploadId: string;
  name: string;
  size: number;
  progress: number;
  eta;
  speed: number;
  status: string;

  constructor(state: UploadState) {
    this.uploadId = state.uploadId;
    this.name = state.name;
    this.size = state.size;
    this.progress = state.progress;
    this.status = state.status;
  }

  setState(state: UploadState) {
    this.progress = state.progress;
    if (state.remaining) {
      this.eta = state.remaining;
      this.speed = state.speed;
    } else {
      this.eta = null;
      this.speed = null;
    }
  }
}
