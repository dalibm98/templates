import {IModel} from '../imodel';

export class CurrentUserDto implements IModel {
  id: number;
  uid: string;
  login: string;
  firstName: string;
  lastName: string;
  email: string;
  imageUrl: string;
  langKey: string;
  authorities: Array<string>;

  constructor() {
    this.authorities = [];
  }

  public getDescription() {
    return this.firstName + ' ' + this.lastName;
  }
}
