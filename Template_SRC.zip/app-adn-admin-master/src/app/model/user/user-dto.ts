import {GroupDto} from '../group/group-dto';
import {CurrentUserDto} from './current-user-dto';

export class UserDto extends CurrentUserDto {

  activated: boolean;
  locked: boolean;

  groups: Array<GroupDto>;

  constructor() {
    super();
    this.authorities = [];
    this.groups = [];
  }

}
