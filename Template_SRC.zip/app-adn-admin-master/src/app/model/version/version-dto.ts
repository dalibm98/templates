import {IModel} from '../imodel';
import {AbstractFollowUpDto} from '../abstract-follow-up-dto';

export class VersionDto extends AbstractFollowUpDto implements IModel {
  id: number;
  uid: string;
  name: string;
  comment: string;
  description: string;
  code: string;
  productUid: string;

  getDescription() {
    return this.name;
  }
}
