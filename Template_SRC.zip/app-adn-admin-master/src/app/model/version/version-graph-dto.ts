export class VersionGraphDto {
  links: GraphLinkDto[];
}

export class GraphLinkDto {
  fromVersion: VersionForGraphDto;
  toVersion: VersionForGraphDto;
}

export class VersionForGraphDto {
  uid: string;
  name: string;
  description: string;
  status: string;
}
