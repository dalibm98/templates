import {VersionDto} from './version-dto';

export class VersionWithAssociatedUpdatesDto extends VersionDto {
  updatesFromVersion: VersionWithUpdateDto[];
  updatesToVersion: VersionWithUpdateDto[];
}

export class VersionWithUpdateDto {
  updateUid: string;
  updateName: string;
  versionUid: string;
  versionName: string;
}
