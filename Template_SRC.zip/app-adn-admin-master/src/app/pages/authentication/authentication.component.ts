import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, ParamMap, Router} from '@angular/router';

import {AuthenticationService} from '../../services/authentication.service';
import {StateStorageService} from '../../services/state-storage.service';

@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.scss']
})
export class AuthenticationComponent implements OnInit {

  username = '';
  password = '';
  rememberMe = false;
  error: any;

  constructor(private authService: AuthenticationService,
              private stateStorage: StateStorageService,
              private router: Router,
              private route: ActivatedRoute) {
  }

  ngOnInit() {
    const token = this.authService.getToken();
    if (token) {
      this.router.navigate(['']);
    }

    this.route.paramMap.subscribe((params: ParamMap) => {
      const reason = params.get('reason');
      if (reason === 'forbidden' || reason === 'unauthorized') {
        this.error = 'login.error.forbidden';
      }
    });
  }

  login(): any {
    this.error = '';
    this.authService.login(this.username, this.password, this.rememberMe)
      .then(() => {
        const redirect = this.stateStorage.getUrl();
        if (redirect && !(/^\/login/.test(redirect)) && !(/^\/activate/.test(redirect))) {
          this.stateStorage.clearUrl();
          this.parseRedirect(redirect);
        } else {
          this.router.navigate(['']);
        }
      }, err => {
        switch (err.status) {
          case 400:
            this.error = 'login.error.incorrect';
            break;
          case 401:
            if (err.error && err.error.exception.indexOf('LockedException') !== -1) {
              this.error = 'login.error.account.locked';
            } else {
              this.error = 'login.error.account.activated';
            }
            break;
        }
      });
    return false;
  }

  private parseRedirect(redirect: string) {
    let url = redirect;
    if (redirect.indexOf(';') !== -1) {
      const urlParams = redirect.split(';');
      url = urlParams.shift();

      const params = {};
      urlParams.forEach(param => {
        const keyValue = param.split('=');
        params[keyValue[0]] = keyValue[1];
      });

      this.router.navigate([url, params]);
    } else {
      this.router.navigate([url]);
    }
  }
}
