import {Component, OnInit} from '@angular/core';
import {GroupService} from '../../services/group.service';
import {GroupWithUserDto} from '../../model/group/group-with-user-dto';
import {ProductService} from '../../services/product.service';
import {ProductDtoWithSimpleRights} from '../../model/product/product-dto-with-simple-rights';
import {UserDto} from '../../model/user/user-dto';
import {BsModalService} from 'ngx-bootstrap/modal';
import {ModalOptions} from 'ngx-bootstrap';
import {SimpleProductRightDto} from '../../model/group/group-dto';
import {AbstractDetailComponent} from '../../components/detail/abstract-detail.component';
import {UserTableComponent} from '../user_management/user-table.component';
import {SelectItemsByTableModalComponent} from '../../components/modal/select-items/select-items-by-table-modal.component';
import {ProductTableComponent} from '../product/product-table.component';

@Component({
  selector: 'app-group-detail',
  templateUrl: './group-detail.component.html'
})
export class GroupDetailComponent extends AbstractDetailComponent<GroupWithUserDto, GroupService> implements OnInit {

  products: Array<ProductDtoWithSimpleRights>;

  isInModal = false;
  isShowAddProducts = false;

  constructor(private groupService: GroupService,
              private productService: ProductService,
              protected modalService: BsModalService) {
    super(GroupWithUserDto, groupService, modalService);
  }

  ngOnInit(): void {
    this.productService.getAllProductsForAllUsers().then(res => {
      this.products = res;
    });
  }

  initCurrentDetail() {
    this.currentDetail = JSON.parse(JSON.stringify(this.originDetail));
  }

  // noinspection JSMethodCanBeStatic
  updateRight(product, right) {
    product.productRight = right;
  }

  showAddProducts() {
    this.isShowAddProducts = true;
    if (!this.isInModal) {
      const modalOptions = new ModalOptions();
      modalOptions.initialState = {
        'inputForceList': this.products,
        'inputSelectedList': this.currentDetail.productRightDtoList,
        'inputBindLabel': 'name',
        'inputTableComponentToCreate': ProductTableComponent
      };
      const bsModalRef = this.modalService.show(SelectItemsByTableModalComponent, modalOptions);
      bsModalRef.content.onClose.subscribe(result => {
        if (result) {
          this.addProducts(result);
        }
      });
    }
  }

  addProducts(products) {
    this.currentDetail.productRightDtoList = products.map(res => {
      const productRightDto = new SimpleProductRightDto();
      productRightDto.name = res.name;
      productRightDto.uid = res.uid;
      const presentPR = this.currentDetail.productRightDtoList.find(pr => pr.uid === res.uid);
      if (presentPR) {
        productRightDto.productRight = presentPR.productRight;
      } else {
        productRightDto.productRight = 'READER';
      }
      return productRightDto;
    });

    this.closeAddProducts();
  }

  closeAddProducts() {
    this.isShowAddProducts = false;
  }

  removeProduct(product: SimpleProductRightDto) {
    const productRights = this.currentDetail.productRightDtoList;
    const productRightIndex = productRights.indexOf(product);
    if (productRightIndex !== -1) {
      productRights.splice(productRightIndex, 1);
    }
  }

  addUsers() {
    const modalOptions = new ModalOptions();

    modalOptions.initialState = {
      'inputSelectedList': this.currentDetail.users,
      'inputBindLabel': 'login',
      'inputTableComponentToCreate': UserTableComponent
    };

    const bsModalRef = this.modalService.show(SelectItemsByTableModalComponent, modalOptions);
    bsModalRef.content.onClose.subscribe(result => {
      if (result) {
        this.currentDetail.users = result;
      }
    });
  }

  removeUser(user: UserDto) {
    const users = this.currentDetail.users;
    const userIndex = users.indexOf(user);
    if (userIndex !== -1) {
      users.splice(userIndex, 1);
    }
  }

}
