import {AbstractTableComponent} from '../../components/table/abstract-table.component';
import {Component} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {Observable, Observer} from 'rxjs';
import {GroupDto} from '../../model/group/group-dto';
import {GroupService} from '../../services/group.service';

@Component({
  selector: 'app-group-table',
  templateUrl: '../../components/table/table.component.html',
})
export class GroupTableComponent extends AbstractTableComponent<GroupDto, GroupService> {

  constructor(protected groupService: GroupService, private translate: TranslateService) {
    super(groupService);
  }

  protected initTableColumns(): Observable<void> {
    return Observable.create((observer: Observer<void>) => {
      this.translate.get('group.name').subscribe(nameColumnName => {
        this.translate.get('group.comment').subscribe(commentColumnName => {
          this.translate.get('group.rights').subscribe(rightColumnName => {
            this.columns = [
              {title: nameColumnName, name: 'name'},
              {title: commentColumnName, name: 'comment'},
              {title: rightColumnName, name: 'groupRights'},
            ];
            observer.complete();
          });
        });
      });
    });
  }

  protected initFilterPlaceholder() {
    this.translate.get('table.filter.all').subscribe(filterPlaceholder => {
      this.filterPlaceholder = filterPlaceholder;
    });
  }

  protected reduceData(rows: Array<GroupDto>): Array<any> {
    return rows.map(group => {
      return {
        uid: group.uid,
        name: group.name,
        comment: group.comment,
        groupRights: group.productRightDtoList.map(productRight => productRight.name + ' : ' + productRight.productRight)
      };
    });
  }
}
