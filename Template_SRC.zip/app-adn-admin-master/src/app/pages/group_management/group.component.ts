import {Component, HostBinding, ViewChild} from '@angular/core';

import {GroupDto} from '../../model/group/group-dto';
import {GroupWithUserDto} from '../../model/group/group-with-user-dto';
import {GroupTableComponent} from './group-table.component';

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
})
export class GroupComponent {
  @HostBinding('class') cssClass = 'd-flex h-100';

  @ViewChild(GroupTableComponent) groupTableComponentRef: GroupTableComponent;

  uid: string;

  constructor() {
  }

  selectGroup(group: GroupDto) {
    this.uid = group.uid;
  }

  onNewDetail() {
    this.uid = null;
    this.groupTableComponentRef.highlightSelectedRow(null);
  }

  onUpdateDetail(event: GroupWithUserDto) {
    this.groupTableComponentRef.tableSelectedItems = [event];
    this.groupTableComponentRef.updateTable();
  }

  onDeleteDetail() {
    this.groupTableComponentRef.updateTable();
  }

}
