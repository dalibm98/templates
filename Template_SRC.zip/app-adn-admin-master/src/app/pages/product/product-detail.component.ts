import {Component, EventEmitter, Input, Output} from '@angular/core';
import {ProductDto} from '../../model/product/product-dto';
import {AbstractDetailComponent} from '../../components/detail/abstract-detail.component';
import {ProductService} from '../../services/product.service';
import {BsModalService} from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html'
})
export class ProductDetailComponent extends AbstractDetailComponent<ProductDto, ProductService> {

  @Input() productRight: string;

  _isCreate: boolean;
  @Input()
  set isCreate(isCreate: boolean) {
    this._isCreate = isCreate;
    if (isCreate) {
      this.new(null);
    }
  }

  @Output() cancelCreateEvent: EventEmitter<any> = new EventEmitter();

  currentIcon: any;

  latestVersions = [];
  latestUpdates = [];
  latestPublishedUpdates = [];
  readonly = true;
  profiles: string;

  constructor(protected productService: ProductService,
              protected modalService: BsModalService) {
    super(ProductDto, productService, modalService);
  }

  protected initCurrentDetail() {
    this.latestVersions = [];
    this.latestUpdates = [];
    this.latestPublishedUpdates = [];
    this.profiles = this.originDetail.profiles.toString();

    this.originDetail.versions.sort((prev, next) => {
      return next.createdDate - prev.createdDate;
    }).slice(0, 5)
      .forEach(version => {
        this.latestVersions.push({
          uid: version.uid,
          name: version.name,
          comment: version.comment
        });
      });

    this.originDetail.updates
      .filter(update => update.status === 'PUBLISHED')
      .sort((prev, next) => {
        return next.createdDate - prev.createdDate;
      }).slice(0, 5)
      .forEach(update => {
        this.latestPublishedUpdates.push({
          uid: update.uid,
          name: update.name,
          comment: update.comment
        });
      });

    this.originDetail.updates.sort((prev, next) => {
      return next.createdDate - prev.createdDate;
    }).slice(0, 5)
      .forEach(update => {
        this.latestUpdates.push({
          uid: update.uid,
          name: update.name,
          comment: update.comment,
          status: update.status
        });
      });

    this.currentDetail = JSON.parse(JSON.stringify(this.originDetail));
    if (this.currentDetail.icon) {
      // TODO add url processing
      // this.currentIcon = this.domSanitizer.bypassSecurityTrustUrl('data:image/png;base64,' + this.currentDetail.icon);
      this.currentIcon = 'data:image/png;base64,' + this.currentDetail.icon;
    } else {
      this.currentIcon = '';
    }
  }

  protected preEdit() {
    this.profiles = this.profiles.replace(/,/g, ',\n');
  }

  protected preSave() {
    this.currentDetail.icon = this.currentIcon.split(',')[1];
    this.currentDetail.profiles = this.profiles.split(',').map(prof => prof.replace(/\n/g, '').trim());
  }

  protected postCancel() {
    if (this._isCreate) {
      this.cancelCreateEvent.emit(null);
    }
    this._isCreate = false;
  }

  protected preNew() {
    this.currentIcon = '';
    this.profiles = '';
    this.latestVersions = [];
    this.latestUpdates = [];
    this.latestPublishedUpdates = [];
  }

  selectIcon(event) {
    const reader = new FileReader();

    const file = event.target.files[0];
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.currentIcon = reader.result;
    };
  }
}
