import {Component, EventEmitter, Input, Output, ViewChild} from '@angular/core';
import {VersionComponent} from '../version/version.component';
import {Router} from '@angular/router';
import {VersionGraphComponent} from '../version/graph/version-graph.component';
import {ProductDetailComponent} from './product-detail.component';

@Component({
  selector: 'app-product-panel',
  templateUrl: './product-panel.component.html'
})
export class ProductPanelComponent {

  @ViewChild(ProductDetailComponent) productDetailComponentRef: ProductDetailComponent;
  @ViewChild(VersionComponent) versionComponentRef: VersionComponent;
  @ViewChild(VersionGraphComponent) versionGraphComponentRef: VersionGraphComponent;

  @Input() currentRight: string;
  @Input() uid: string;

  @Input() isCreateProduct: boolean;

  @Output() productUpdateEvent: EventEmitter<any> = new EventEmitter();
  @Output() productCreateEvent: EventEmitter<any> = new EventEmitter();

  constructor(private router: Router) {
  }

  updateProduct(event) {
    if (this.isCreateProduct) {
      this.createdProduct(event);
    } else {
      this.productUpdateEvent.emit(event);
    }
  }

  createdProduct(event) {
    this.isCreateProduct = false;
    if (event) {
      this.productCreateEvent.emit(event);
    }
  }

  onUpdateDeleteVersion() {
    this.productDetailComponentRef.refreshDetail();
    this.versionGraphComponentRef.updateGraph();
  }

  onUpdateDeleteUpdate() {
    this.productDetailComponentRef.refreshDetail();
    this.versionComponentRef.versionDetailComponentRef.refreshDetail();
    this.versionGraphComponentRef.updateGraph();
  }

  createUpdate() {
    this.router.navigate(['/update_creation', this.uid]);
  }
}
