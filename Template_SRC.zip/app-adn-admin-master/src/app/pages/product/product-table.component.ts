import {AbstractTableComponent} from '../../components/table/abstract-table.component';
import {Component, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {Observable, Observer} from 'rxjs';
import {ProductDtoWithSimpleRights} from '../../model/product/product-dto-with-simple-rights';
import {ProductService} from '../../services/product.service';

@Component({
  selector: 'app-product-table',
  templateUrl: '../../components/table/table.component.html',
})
export class ProductTableComponent extends AbstractTableComponent<ProductDtoWithSimpleRights, ProductService> {

  @Input() onlyForManager = false;
  @Input() onlyForReporter = false;

  constructor(protected productService: ProductService, private translate: TranslateService) {
    super(productService);
  }

  protected initTableColumns(): Observable<void> {
    return Observable.create((observer: Observer<void>) => {
      this.translate.get('global.name').subscribe(productNameColumnName => {
        this.translate.get('global.comment').subscribe(productCommentColumnName => {
          this.translate.get('product.rights').subscribe(productRightsColumnName => {
            this.columns = [
              {title: productNameColumnName, name: 'name', sort: false},
              {title: productCommentColumnName, name: 'comment', sort: false}
            ];
            if (!this.multipleSelect) {
              this.columns.push({title: productRightsColumnName, name: 'right', sort: false});
            }
            observer.complete();
          });
        });
      });
    });
  }

  protected initFilterPlaceholder() {
    this.translate.get('table.filter.all').subscribe(filterPlaceholder => {
      this.filterPlaceholder = filterPlaceholder;
    });
  }

  protected reduceData(rows: Array<ProductDtoWithSimpleRights>): Array<any> {
    const reducedRows = [];
    rows.forEach(row => {
      if (this.isRowWanted(row)) {
        reducedRows.push({
          'uid': row.uid,
          'name': row.name,
          'comment': row.comment,
          'right': this.getRightCell(row.right)
        });
      }
    });
    return reducedRows;
  }

  private isRowWanted(row: ProductDtoWithSimpleRights) {
    if (this.onlyForManager) {
      return row.right === 'MANAGER';
    } else if (this.onlyForReporter) {
      return row.right === 'MANAGER' || row.right === 'REPORTER';
    } else {
      return true;
    }
  }

  private getRightCell(right: string) {
    let faIcon: string;
    switch (right) {
      case 'READER':
        faIcon = '<i class="fa fa-book"></i>';
        break;
      case 'REPORTER':
        faIcon = '<i class="fa fa-flag"></i>';
        break;
      case 'MANAGER':
        faIcon = '<i class="fa fa-user-plus"></i>';
        break;
    }
    return faIcon + '&nbsp;' + right;
  }

  getRightFromCell(cellRight: string) {
    return cellRight.split('&nbsp;')[1];
  }
}
