import {Component, HostBinding, OnInit, ViewChild} from '@angular/core';

import {ProductDtoWithSimpleRights} from '../../model/product/product-dto-with-simple-rights';
import {ProductTableComponent} from './product-table.component';
import {ActivatedRoute, Router} from '@angular/router';
import {ProductService} from '../../services/product.service';
import {CurrentUserService} from '../../services/current-user.service';
import {ProductPanelComponent} from './product-panel.component';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
})
export class ProductComponent implements OnInit {
  @HostBinding('class') cssClass = 'd-flex h-100';

  @ViewChild(ProductTableComponent) productTableComponentRef: ProductTableComponent;
  @ViewChild(ProductPanelComponent) productPanelComponentRef: ProductPanelComponent;

  uid: string;
  selectedProductByUid: ProductDtoWithSimpleRights;
  currentRight: string;
  isCreateProduct = false;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private productService: ProductService,
              public currentUserService: CurrentUserService) {
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      const paramProductUid = params['uid'];
      if (paramProductUid) {
        this.productService.getSimpleProductWithRightByUid(paramProductUid).then(product => {
          this.selectedProductByUid = product;
          this.uid = product.uid;
          this.currentRight = product.right;
          this.isCreateProduct = false;
        }, err => {
          if (err.status !== 401) {
            this.router.navigate(['product']);
          }
        });
      }
    });
  }

  // Click on product table
  selectProduct(product: any) {
    this.router.navigate(['product', {uid: product.uid}]);
  }

  onUpdateDetail(event: ProductDtoWithSimpleRights) {
    this.productTableComponentRef.updateTable();
  }

  newProduct() {
    this.uid = null;
    this.currentRight = null;
    this.isCreateProduct = true;
    this.productTableComponentRef.highlightSelectedRow(null);
    this.router.navigate(['product']);
  }

  onCreateProduct(event) {
    this.router.navigate(['group_management']);
  }
}
