import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {VersionDto} from '../../../model/version/version-dto';
import {Observable} from 'rxjs';
import {VersionService} from '../../../services/version.service';
import {SearchDto} from '../../../model/search/search-dto';
import {debounceTime, distinctUntilChanged, switchMap} from 'rxjs/operators';
import {of} from 'rxjs/internal/observable/of';

@Component({
  selector: 'app-statistic-filter',
  templateUrl: './statistic-filter.component.html',
})
export class StatisticFilterComponent implements OnInit {
  @Input() productUid: string;
  @Input() statisticType: string;
  @Input() disableFilter: string;

  @Output() filterChanged: EventEmitter<StatFilter> = new EventEmitter<StatFilter>();

  statFilter: StatFilter = new StatFilter();

  osList = [{
    'name': 'Windows 5.0',
    'value': 'Windows\\ 5.0'
  }, {
    'name': 'Windows 5.1',
    'value': 'Windows\\ 5.1'
  }, {
    'name': 'Windows 6.0',
    'value': 'Windows\\ 6.0'
  }, {
    'name': 'Windows 6.1',
    'value': 'Windows\\ 6.1'
  }, {
    'name': 'Windows 6.2',
    'value': 'Windows\\ 6.2'
  }, {
    'name': 'Windows 6.3',
    'value': 'Windows\\ 6.3'
  }, {
    'name': 'Windows 7',
    'value': 'Windows\\ 7\\ \\(API\\ Builder\\)'
  }, {
    'name': 'Windows 10',
    'value': 'Windows\\ 10\\)'
  }, {
    'name': 'Windows 10.0',
    'value': 'Windows\\ 10.0'
  }];

  langList = [{
    'name': 'Français',
    'value': 'fr'
  }, {
    'name': 'Anglais',
    'value': 'en'
  }, {
    'name': 'Espagnol',
    'value': 'es'
  }, {
    'name': 'Allemand',
    'value': 'de'
  }, {
    'name': 'Néerlandais',
    'value': 'nl'
  }, {
    'name': 'Tchèque',
    'value': 'cs'
  }, {
    'name': 'Portugais',
    'value': 'pt'
  }, {
    'name': 'Croate',
    'value': 'hr'
  }, {
    'name': 'Italien',
    'value': 'it'
  }, {
    'name': 'Grec',
    'value': 'el'
  }, {
    'name': 'Danois',
    'value': 'da'
  }, {
    'name': 'Finnois',
    'value': 'fi'
  }, {
    'name': 'Hongrois',
    'value': 'hu'
  }, {
    'name': 'Japonais',
    'value': 'ja'
  }, {
    'name': 'Polonais',
    'value': 'pl'
  }, {
    'name': 'Russe',
    'value': 'ru'
  }, {
    'name': 'Suédois',
    'value': 'sv'
  }, {
    'name': 'Turc',
    'value': 'tr'
  }, {
    'name': 'Slovène',
    'value': 'sl'
  }, {
    'name': 'Chinois',
    'value': 'zh'
  }, {
    'name': 'Roumain',
    'value': 'ro'
  }, {
    'name': 'Coréen',
    'value': 'ko'
  }, {
    'name': 'Arabe',
    'value': 'ar'
  }, {
    'name': 'Farsi',
    'value': 'fa'
  }];

  archList = [{
    'name': 'x86',
    'value': 'x86'
  }, {
    'name': 'x64',
    'value': 'x64'
  }];

  stateList = [{
    'name': 'Download',
    'value': 'DOWNLOAD'
  }, {
    'name': 'Installation',
    'value': 'INSTALLATION'
  }];

  statusList = [{
    'name': 'Success',
    'value': 'SUCCESS'
  }, {
    'name': 'Failed',
    'value': 'FAILED'
  }, {
    'name': 'Stopped',
    'value': 'STOPPED'
  }];

  typeaheadVersions = new EventEmitter<string>();
  foundVersions: VersionDto[] = [];

  constructor(private versionService: VersionService) {
  }

  public ngOnInit() {
    this.typeaheadVersions.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      switchMap(term => {
        this.statFilter.versionFilter = term;
        const search = new SearchDto(100, 0, this.statFilter.versionFilter);
        return term ? this.versionService.getAllByProductId(this.productUid, search) : of([]);
      })
    ).subscribe(items => {
      this.foundVersions = items['content'];
    }, (err) => {
      console.log(err);
      this.foundVersions = [];
    });
  }

  updateAtDate(event) {
    this.statFilter.dateAtFilter = event;
    this.sendFilterChanged();
  }

  updateRangeDate(event) {
    this.statFilter.dateFromFilter = event[0];
    this.statFilter.dateToFilter = event[1];
    this.sendFilterChanged();
  }

  sendFilterChanged() {
    this.filterChanged.emit(this.statFilter);
  }
}

export class StatFilter {
  osFilter = '';
  langFilter = '';
  versionFilter;
  archFilter = '';
  stateFilter = '';
  statusFilter = '';

  private _dateAtFilter = new Date();
  get dateAtFilter() {
    try {
      this._dateAtFilter.getTime();
      return this._dateAtFilter;
    } catch {
      this._dateAtFilter = new Date();
      return this._dateAtFilter;
    }
  }

  set dateAtFilter(dateAtFilter: Date) {
    this._dateAtFilter = dateAtFilter;
  }

  private _dateFromFilter = new Date();
  get dateFromFilter() {
    try {
      this._dateFromFilter.getTime();
      return this._dateFromFilter;
    } catch {
      this._dateFromFilter = new Date();
      return this._dateFromFilter;
    }
  }

  set dateFromFilter(dateFromFilter: Date) {
    this._dateFromFilter = dateFromFilter;
  }

  private _dateToFilter = new Date();
  get dateToFilter() {
    try {
      this._dateToFilter.getTime();
      return this._dateToFilter;
    } catch {
      this._dateToFilter = new Date();
      return this._dateToFilter;
    }
  }

  set dateToFilter(dateToFilter: Date) {
    this._dateToFilter = dateToFilter;
  }
}
