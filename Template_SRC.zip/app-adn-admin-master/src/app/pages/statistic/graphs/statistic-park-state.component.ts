import {Component, Input} from '@angular/core';
import {StatisticService} from '../../../services/statistic.service';
import {StatFilter} from '../filter/statistic-filter.component';
import {ProductDto} from '../../../model/product/product-dto';

@Component({
  selector: 'app-statistic-park-state',
  templateUrl: './statistic-park-state.component.html',
})
export class StatisticParkStateComponent {
  private _productCode: string;
  productUid: string;

  filter: StatFilter = new StatFilter();
  xAxis = '';

  chartColors = {
    domain: [
      '#9999FF','#0066CC','#99CCCC','#999999','#FFCC00','#009999',
      '#3399FF','#993300','#CCCC99','#666666','#FFCC66','#6699CC',
      '#336699','#99CCFF','#999933','#666699','#CC9933','#006666',
      '#663366','#9999CC','#CCCCCC','#669999','#CCCC66','#CC6600',
      '#99CC33','#FF9900','#999966','#66CCCC','#339966','#CCCC33'
    ]
  };

  fullStateData = [];
  stateData = [];

  constructor(private statisticService: StatisticService) {
  }

  @Input()
  set product(product: ProductDto) {
    if (!product) {      return;
    }
    this._productCode = product.code;
    this.productUid = product.uid;
    this.initFields();
  }

  private initFields() {
    this.xAxis = '';
    this.fullStateData = [];
    this.stateData = [];
  }

  refreshPieData(filter?: StatFilter) {
    if (filter) {
      this.filter = filter;
    }

    const query = this.prepareQuery(this.filter);
    this.statisticService.getParkStatByProduct(this._productCode, query, this.xAxis, this.filter.dateAtFilter.getTime().toString())
      .then(res => {
        var sorted = [...Object.entries(res)].sort((a,b) => a[1] > b[1] ? -1 : a[1] < b[1] ? 1 : 0);
        this.fullStateData = sorted.map(entry => {
          return {'name': entry[0], 'value': entry[1]};
        });

        let nbRecords = 0;
        this.fullStateData.forEach(entry => {
          nbRecords += entry.value;
        });

        this.stateData = [];
        let other = 0;
        this.fullStateData.forEach(entry => {
          if (entry.value < nbRecords / 200) {
            // remove entries > 0,5% from displaying individually
            other += entry.value;
          } else {
            this.stateData = this.stateData.concat(entry);
          }
        });

        if (other > 0) {
          this.stateData = this.stateData.concat({'name': '(other)', 'value': other});
        }

      });
  }

  prepareQuery(filter: StatFilter) {
    let query = '';

    if (filter.osFilter && this.xAxis !== 'os') {
      query += 'os=' + filter.osFilter + ' AND ';
    }
    if (filter.archFilter && this.xAxis !== 'arch') {
      query += 'arch=' + filter.archFilter + ' AND ';
    }
    if (filter.langFilter && this.xAxis !== 'lang') {
      query += 'lang=' + filter.langFilter + ' AND ';
    }
    if (filter.versionFilter && this.xAxis !== 'productVersion') {
      query += 'productVersion=' + filter.versionFilter + ' AND ';
    }

    if (query.length > ' AND '.length) {
      query = query.substring(0, query.length - ' AND '.length);
    }
    return query;
  }

  exportAsExcel() {
    const jsonExcel = [];
    this.fullStateData.forEach(entry => {
      const lineInExcel = {};
      lineInExcel[this.xAxis] = entry['name'];
      lineInExcel['value'] = entry['value'];
      jsonExcel.push(lineInExcel);
    });
    this.statisticService.exportAsExcelFile(jsonExcel, this.getExcelName());
  }

  getExcelName() {
    let excelName = 'parkstate_on=' + this.xAxis;
    excelName += '_date=' + this.filter.dateAtFilter.toLocaleDateString().replace(/\//g, '-');

    if (this.filter.osFilter && this.xAxis !== 'os') {
      excelName += '_os=' + this.filter.osFilter;
    }
    if (this.filter.archFilter && this.xAxis !== 'arch') {
      excelName += '_arch=' + this.filter.archFilter;
    }
    if (this.filter.langFilter && this.xAxis !== 'lang') {
      excelName += '_lang=' + this.filter.langFilter;
    }
    if (this.filter.versionFilter && this.xAxis !== 'productVersion') {
      excelName += '_productVersion=' + this.filter.versionFilter;
    }

    return excelName;
  }
}
