import {Component, Input} from '@angular/core';
import {StatisticService} from '../../../services/statistic.service';
import {StatFilter} from '../filter/statistic-filter.component';
import {ProductDto} from '../../../model/product/product-dto';

@Component({
  selector: 'app-statistic-requests',
  templateUrl: './statistic-requests.component.html',
})
export class StatisticRequestsComponent {
  private _productCode: string;
  productUid: string;

  filter: StatFilter = new StatFilter();
  yAxis = '';
  requestData = [];

  constructor(private statisticService: StatisticService) {
  }

  @Input()
  set product(product: ProductDto) {
    if (!product) {
      return;
    }
    this._productCode = product.code;
    this.productUid = product.uid;
    this.initFields();
  }

  private initFields() {
    this.yAxis = '';
    this.requestData = [];
  }

  refreshBarData(filter?: StatFilter) {
    if (filter) {
      this.filter = filter;
    }

    const query = this.prepareQuery(this.filter);
    this.statisticService.getNumberOfRequestsBetweenDates(this._productCode, query, this.filter.dateFromFilter.getTime().toString(), this.filter.dateToFilter.getTime().toString(), this.yAxis)
      .then(res => {
        this.requestData = Object.entries(res).map(entry => {
          const serie = {};
          serie['name'] = entry[0];
          serie['series'] = Object.entries(entry[1]).map(innerEntry => {
            return {'name': innerEntry[0], 'value': innerEntry[1]};
          });
          return serie;
        });
      }, err => {
      });
  }

  prepareQuery(filter: StatFilter) {
    let query = '';

    if (filter.osFilter && this.yAxis !== 'os') {
      query += 'os:' + filter.osFilter + ' AND ';
    }
    if (filter.archFilter && this.yAxis !== 'arch') {
      query += 'arch:' + filter.archFilter + ' AND ';
    }
    if (filter.langFilter && this.yAxis !== 'lang') {
      query += 'lang:' + filter.langFilter + ' AND ';
    }
    if (filter.versionFilter && this.yAxis !== 'productVersion') {
      query += 'version:' + filter.versionFilter + ' AND ';
    }
    if (filter.stateFilter && this.yAxis !== 'state') {
      query += 'state:' + filter.stateFilter + ' AND ';
    }
    if (filter.statusFilter && this.yAxis !== 'status') {
      query += 'status:' + filter.statusFilter + ' AND ';
    }

    if (query.length > ' AND '.length) {
      query = query.substring(0, query.length - ' AND '.length);
    }
    return query;
  }

  xAxisTickFormatting(data) {
    const date = new Date(Number(data));
    let result = date.toLocaleDateString();
    // Here 'this' is XAxisTickComponent, but typescript won't let cast 'this' to XAxisTickComponent
    if (this['ticks'].length > 1 && this['ticks'][1] - this['ticks'][0] < 86400000) {
      const hours = date.getHours().toString();
      result += ' ';
      if (hours.length === 1) {
        result += '0';
      }
      result += hours + ':00';
    }
    return result;
  }

  exportAsExcel() {
    const jsonExcel = [];
    this.requestData.forEach(entry => {
      entry['series'].forEach(serie => {
        const lineInExcel = {};
        lineInExcel['date'] = entry['name'];
        lineInExcel[this.yAxis] = serie['name'];
        lineInExcel['numberOfRequests'] = serie['value'];
        jsonExcel.push(lineInExcel);
      });
    });
    this.statisticService.exportAsExcelFile(jsonExcel, this.getExcelName());
  }

  getExcelName() {
    let excelName = 'requests_on=' + this.yAxis;
    excelName += '_fromDate=' + this.filter.dateFromFilter.toLocaleDateString().replace(/\//g, '-');
    excelName += '_toDate=' + this.filter.dateToFilter.toLocaleDateString().replace(/\//g, '-');

    if (this.filter.osFilter && this.yAxis !== 'os') {
      excelName += '_os=' + this.filter.osFilter;
    }
    if (this.filter.archFilter && this.yAxis !== 'arch') {
      excelName += '_arch=' + this.filter.archFilter;
    }
    if (this.filter.langFilter && this.yAxis !== 'lang') {
      excelName += '_lang=' + this.filter.langFilter;
    }
    if (this.filter.versionFilter && this.yAxis !== 'productVersion') {
      excelName += '_productVersion=' + this.filter.versionFilter;
    }

    return excelName;
  }
}
