import {Component, Input} from '@angular/core';
import {ProductService} from '../../services/product.service';
import {ProductDto} from '../../model/product/product-dto';
import {StatisticService} from '../../services/statistic.service';
import {BsLocaleService} from 'ngx-bootstrap';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-statistic-panel',
  templateUrl: './statistic-panel.component.html',
})
export class StatisticPanelComponent {

  product: ProductDto;

  constructor(protected productService: ProductService,
              private statisticService: StatisticService,
              private localeService: BsLocaleService,
              private translate: TranslateService) {
    this.localeService.use(this.translate.currentLang);
  }

  @Input()
  set uid(uid: string) {
    if (!uid) {
      return;
    }
    this.initProductInfo(uid);
  }

  private initProductInfo(productUid) {
    this.productService.getByUid(productUid).then(product => {
      this.product = product;
    });
  }

}
