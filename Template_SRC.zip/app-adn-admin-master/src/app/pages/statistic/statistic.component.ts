import {ProductDtoWithSimpleRights} from '../../model/product/product-dto-with-simple-rights';
import {Component, HostBinding} from '@angular/core';

@Component({
  selector: 'app-statistic',
  templateUrl: './statistic.component.html',
})
export class StatisticComponent {
  @HostBinding('class') cssClass = 'd-flex h-100';

  uid: string;

  constructor() {
  }

  public selectProduct(product: ProductDtoWithSimpleRights) {
    this.uid = product.uid;
  }

}
