import {Component, HostBinding, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ProductDto} from '../../../model/product/product-dto';
import {ProductService} from '../../../services/product.service';
import {VersionDto} from '../../../model/version/version-dto';
import {VersionService} from '../../../services/version.service';
import {VersionTableComponent} from '../../version/version-table.component';
import {UpdateDetailComponent} from '../update-detail.component';
import {UpdateFullDto} from '../../../model/update/update-full-dto';
import {UpdateService} from '../../../services/update.service';
import {ConfirmModalComponent} from '../../../components/modal/confirm/confirm-modal.component';
import {ModalOptions} from 'ngx-bootstrap';
import {BsModalService} from 'ngx-bootstrap/modal';
import {distinctUntilChanged} from 'rxjs/operators';

@Component({
  selector: 'app-update-create-panel',
  templateUrl: './update-create-panel.component.html',
  styleUrls: ['./update-create-panel.component.scss'],
})
export class UpdateCreatePanelComponent implements OnInit {
  @HostBinding('class') cssClass = 'd-flex h-100';

  currentStep: number;
  isCurrentStepValid = false;
  currentTitle: string;
  currentPreviousTooltip: string;
  currentNextTooltip: string;

  selectedProduct: ProductDto;

  @ViewChild('appliedVersionsTable') appliedVersionsTableComponentRef: VersionTableComponent;
  @ViewChild('linkedVersionTable') linkedVersionTableComponentRef: VersionTableComponent;
  applied_versions: VersionDto[] = [];
  linked_version: VersionDto;
  newVersion: VersionDto;

  @ViewChild('updateDetail') updateDetailComponentRef: UpdateDetailComponent;
  currentUpdate: UpdateFullDto;

  constructor(private productService: ProductService,
              private versionService: VersionService,
              private updateService: UpdateService,
              private modalService: BsModalService,
              private route: ActivatedRoute,
              private router: Router) {
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      const productUid = params['productUid'];

      if (productUid) {
        this.productService.getByUid(productUid).then(
          response => {
            this.selectedProduct = response;
            this.currentStep = 1;
            this.initCurrentStep();
          }, err => {
            console.log(err);
            this.currentStep = 1;
            this.initCurrentStep();
          });
      } else {
        this.currentStep = 1;
        this.initCurrentStep();
      }

      this.currentUpdate = new UpdateFullDto();
      this.currentUpdate.titles = {};
      this.currentUpdate.descriptions = {};
      this.currentUpdate.status = 'PENDING';
    });
  }

  private setCurrentTitle() {
    switch (this.currentStep) {
      case 1:
        this.currentTitle = 'update.create.title.product';
        this.currentPreviousTooltip = '';
        this.currentNextTooltip = 'update.create.tooltip.next1';
        break;
      case 2:
        this.currentTitle = 'update.create.title.version';
        this.currentPreviousTooltip = 'update.create.tooltip.prev2';
        this.currentNextTooltip = 'update.create.tooltip.next2';
        break;
      case 3:
        this.currentTitle = 'update.create.title.update';
        this.currentPreviousTooltip = 'update.create.tooltip.prev3';
        this.currentNextTooltip = 'update.create.tooltip.next3';
        break;
      case 4:
        this.currentTitle = 'update.create.title.summary';
        this.currentPreviousTooltip = 'update.create.tooltip.prev4';
        this.currentNextTooltip = 'update.create.tooltip.next4';
        break;
      default:
        this.currentTitle = 'update.create.title.notfound';
    }
  }

  private checkCurrentStep() {
    switch (this.currentStep) {
      case 1:
        this.isCurrentStepValid = !!this.selectedProduct;
        break;
      case 2:
        this.isCurrentStepValid = (this.currentUpdate.majorUpdate || (this.applied_versions.length !== 0)) && !!this.linked_version;
        break;
      case 3:
        this.isCurrentStepValid = this.updateDetailComponentRef.updateDetailForm.valid;
        this.updateDetailComponentRef.updateDetailForm.statusChanges.pipe(distinctUntilChanged()).subscribe(status => {
          this.isCurrentStepValid = status === 'VALID';
        });
        break;
      case 4:
        this.isCurrentStepValid = false;
        break;
      default:
        this.isCurrentStepValid = false;
    }
  }

  private initCurrentStep() {
    this.setCurrentTitle();
    // Timeout to let the time at the component to render
    setTimeout(() => {
      switch (this.currentStep) {
        case 2:
          this.currentUpdate.productUid = this.selectedProduct.uid;
          break;
        case 3:
          this.currentUpdate.appliedVersions = this.applied_versions;
          this.currentUpdate.linkedVersion = this.linked_version;
          this.updateDetailComponentRef.new(null);
          this.updateDetailComponentRef.setCurrentDetail(this.currentUpdate);
          break;
        default:
          break;
      }
      setTimeout(() => this.checkCurrentStep(), 10);
    }, 10);
  }

  previous() {
    this.currentStep--;
    this.initCurrentStep();
  }

  next() {
    if (this.isCurrentStepValid) {
      this.currentStep++;
      this.initCurrentStep();
    }
  }

  cancel() {
    const modalOptions = new ModalOptions();
    modalOptions.initialState = {
      'confirmMessageKey': 'modal.cancel.update.creation',
      'confirmIcon': 'check',
      'confirmButton': 'button.yes',
      'confirmCancelIcon': 'ban',
      'confirmCancelButton': 'button.no'
    };
    const bsModalRef = this.modalService.show(ConfirmModalComponent, modalOptions);
    bsModalRef.content.onClose.subscribe(cancel => {
      if (cancel) {
        this.router.navigate(['/product']);
      }
    });
  }

  proceed() {
    this.updateService.save(this.currentUpdate).then(savedUpdate => {
      this.router.navigate(['/upload/' + savedUpdate.uid]);
    });
  }

  selectProduct(product: ProductDto) {
    this.selectedProduct = product;
    this.applied_versions = [];
    this.linked_version = null;
    this.checkCurrentStep();
  }

  selectAppliedVersions(versions: VersionDto[]) {
    // Force change array reference
    this.applied_versions = versions.slice(0, versions.length).map(version => {
      version.productUid = this.selectedProduct.uid;
      return version;
    });
    this.checkCurrentStep();
  }

  selectLinkedVersion(version: VersionDto) {
    this.linked_version = version;
    this.linked_version.productUid = this.selectedProduct.uid;
    this.checkCurrentStep();
  }

  createNewVersion() {
    this.newVersion = new VersionDto();
    this.newVersion.productUid = this.selectedProduct.uid;
  }

  cancelCreateNewVersion() {
    this.newVersion = null;
  }

  saveCreateNewVersion() {
    this.versionService.save(this.newVersion).then(res => {
      this.linked_version = res;
      this.newVersion = null;
      this.appliedVersionsTableComponentRef.updateTable();
      this.linkedVersionTableComponentRef.updateTable();
      this.currentUpdate.name = this.linked_version.name;
      this.currentUpdate.comment = this.linked_version.comment;
      this.checkCurrentStep();
    });
  }

  majorUpdateChange() {
    if (this.currentUpdate.majorUpdate) {
      this.selectAppliedVersions([]);
      this.appliedVersionsTableComponentRef.updateTable();
    } else {
      //nothing to do
    }
    this.checkCurrentStep();
  }
}
