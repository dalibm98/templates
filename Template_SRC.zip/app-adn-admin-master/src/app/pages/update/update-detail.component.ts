import {AbstractDetailComponent} from '../../components/detail/abstract-detail.component';
import {Component, EventEmitter, Input, OnInit, ViewChild} from '@angular/core';
import {VersionDto} from '../../model/version/version-dto';
import {BsModalService} from 'ngx-bootstrap/modal';
import {UpdateService} from '../../services/update.service';
import {VersionService} from '../../services/version.service';
import {UpdateFileDto, UpdateFullDto} from '../../model/update/update-full-dto';
import {Observable} from 'rxjs/internal/Observable';


import {SearchDto} from '../../model/search/search-dto';
import {ModalOptions} from 'ngx-bootstrap';
import {ConfirmModalComponent} from '../../components/modal/confirm/confirm-modal.component';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router';
import {UploadService} from '../../services/upload.service';
import {ToasterService} from '../../services/toaster.service';
import {TranslateService} from '@ngx-translate/core';
import {debounceTime, distinctUntilChanged, switchMap} from 'rxjs/operators';
import {fromPromise} from 'rxjs/internal-compatibility';

@Component({
  selector: 'app-update-detail',
  templateUrl: './update-detail.component.html'
})
export class UpdateDetailComponent extends AbstractDetailComponent<UpdateFullDto, UpdateService> implements OnInit {

  @ViewChild('updateDetailForm') updateDetailForm: NgForm;

  @Input() private productUid: string;
  @Input() private productRight = 'READER';
  @Input() private isNewUpdate = false;

  // Target/Applied versions
  typeaheadVersions = new EventEmitter<string>();
  linkedVersion: VersionDto;
  appliedVersions: VersionDto[];
  foundVersions: VersionDto[];

  // Status
  nextStatus: string;

  missingDefaultProfileOnUpdateFiles = false;

  constructor(protected updateService: UpdateService,
              protected versionService: VersionService,
              protected modalService: BsModalService,
              private uploadService: UploadService,
              private router: Router,
              private translate: TranslateService,
              private toaster: ToasterService) {
    super(VersionDto, updateService, modalService);
  }

  public ngOnInit() {
    if (!this.isNewUpdate) {
      this.typeaheadVersions.pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap(term => this.getVersionsAsObservable(term))
      ).subscribe(items => {
        this.foundVersions = items.content;
      }, (err) => {
        console.log(err);
        this.foundVersions = [];
      });
    }
  }

  getVersionsAsObservable(token: string): Observable<any> {
    const search = new SearchDto(5, 0, token);
    return fromPromise(this.versionService.getAllByProductId(this.productUid, search));
  }

  setNextStatus() {
    switch (this.currentDetail.status) {
      case 'UNPUBLISHED':
        this.nextStatus = 'IN_TEST';
        break;
      case 'IN_TEST':
        this.nextStatus = 'FIELD_TEST';
        break;
      case 'FIELD_TEST':
        this.nextStatus = 'PUBLISHED';
        break;
      case 'PUBLISHED':
        this.nextStatus = 'SUSPENDED';
        break;
      case 'SUSPENDED':
        this.nextStatus = 'IN_TEST';
        break;
    }
  }

  updateStatus() {
    const modalOptions = new ModalOptions();
    modalOptions.initialState = {
      'confirmMessageKey': 'modal.update.state.confirm',
      'confirmMessageValue': 'update.status.' + this.nextStatus.toLowerCase(),
      'confirmIcon': 'undo',
      'confirmButton': 'button.update'
    };
    if (this.missingDefaultProfileOnUpdateFiles) {
      modalOptions.initialState['confirmMessageValue'] = ['', 'update.status.' + this.nextStatus.toLowerCase()];
      modalOptions.initialState['confirmMessageKey'] = ['warning.update.file.no.default', 'modal.update.state.confirm'];
    }
    this.showUpdateStatusModal(modalOptions, false);
  }

  suspendUpdate() {
    const modalOptions = new ModalOptions();
    modalOptions.initialState = {
      'confirmMessageKey': 'modal.update.state.suspend',
      'confirmIcon': 'stop',
      'confirmButton': 'button.suspend'
    };
    this.showUpdateStatusModal(modalOptions, true);
  }

  private showUpdateStatusModal(modalOptions: ModalOptions, isSuspend: boolean) {
    const bsModalRef = this.modalService.show(ConfirmModalComponent, modalOptions);
    bsModalRef.content.onClose.subscribe(isUpdateStatus => {
      if (isUpdateStatus) {
        if (isSuspend) {
          this.service.suspendUpdate(this.originDetail.uid).then(newStatus => {
            this.originDetail.status = newStatus;
            this.updateEvent.emit();
            this.initCurrentDetail();
          });
        } else {
          this.service.updateStatus(this.originDetail.uid).then(newStatus => {
            this.originDetail.status = newStatus;
            this.updateEvent.emit();
            this.initCurrentDetail();
          });
        }
      }
    });
  }

  goToUpload(uploadUid: string) {
    this.router.navigate(['/upload/' + this.currentDetail.uid, {uploadUid: uploadUid}]);
  }

  goToNewUpload() {
    this.router.navigate(['/upload/' + this.currentDetail.uid]);
  }

  removeUpload(updateFile: UpdateFileDto) {
    const modalOptions = new ModalOptions();
    modalOptions.initialState = {
      'confirmMessageKey': 'modal.upload.delete',
      'confirmMessageValue': updateFile.name,
      'confirmIcon': 'trash',
      'confirmButton': 'button.delete'
    };
    const bsModalRef = this.modalService.show(ConfirmModalComponent, modalOptions);
    bsModalRef.content.onClose.subscribe(isDelete => {
      if (isDelete) {
        this.uploadService.deleteUpload(updateFile.uid).then(res => {
          this.originDetail = res;
          this.initCurrentDetail();
        });
      }
    });
  }

  public resetComponent() {
    this.originDetail = null;
    this.currentDetail = null;
  }

  protected initCurrentDetail() {
    this.setCurrentDetail(JSON.parse(JSON.stringify(this.originDetail)));
    this.missingDefaultProfileOnUpdateFiles =
      this.currentDetail.updateFiles.filter(uf => uf.profiles.indexOf('DEFAULT') !== -1).length === 0;
  }

  setCurrentDetail(currentDetailToSet) {
    this.currentDetail = currentDetailToSet;
    this.linkedVersion = this.currentDetail.linkedVersion;
    this.appliedVersions = this.currentDetail.appliedVersions;
    this.setNextStatus();
  }

  protected preSave() {
    this.currentDetail.linkedVersion = this.linkedVersion;
    this.currentDetail.appliedVersions = this.appliedVersions;
  }

  protected postSave() {
    if (this.missingDefaultProfileOnUpdateFiles) {
      this.translate.get('warning.update.file.no.default').subscribe(warningNoDefaultProfile => {
        this.toaster.warning(warningNoDefaultProfile);
      });
    }
  }

  majorUpdateChange() {
    if (this.currentDetail.majorUpdate) {
      this.appliedVersions = [];
    } else {
      //nothing to do
    }
  }

}
