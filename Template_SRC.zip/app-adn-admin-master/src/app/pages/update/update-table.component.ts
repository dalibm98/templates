import {Component, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {DatePipe} from '@angular/common';

import {AbstractTableComponent} from '../../components/table/abstract-table.component';
import {Observable, Observer} from 'rxjs';
import {SearchDto} from '../../model/search/search-dto';
import {UpdateService} from '../../services/update.service';
import {UpdateDto} from '../../model/update/update-dto';
import {ShortenStringPipe} from '../../pipes/shorten-string.pipe';

@Component({
  selector: 'app-update-table',
  templateUrl: '../../components/table/table.component.html',
})
export class UpdateTableComponent extends AbstractTableComponent<UpdateDto, UpdateService> {

  private _productUid: string;

  constructor(protected updateService: UpdateService,
              private translate: TranslateService,
              private datePipe: DatePipe,
              private shortenStringPipe: ShortenStringPipe) {
    super(updateService);
  }

  @Input()
  set productUid(productUid: string) {
    if (!this._productUid) { // this.onChangeTable() automatically called here
      this._productUid = productUid;
    } else {
      this._productUid = productUid;
      this.onChangeTable(this.config);
    }
  }

  get productUid() {
    return this._productUid;
  }

  protected initTableColumns(): Observable<void> {
    return Observable.create((observer: Observer<void>) => {
      this.translate.get('global.name').subscribe(updateNameColumnName => {
        this.translate.get('global.comment').subscribe(updateCommentColumnName => {
          this.translate.get('global.creation_date').subscribe(updateDateColumnName => {
            this.translate.get('global.status').subscribe(updateStateColumnName => {
              this.columns = [
                {title: updateNameColumnName, name: 'name', sort: ''},
                {title: updateCommentColumnName, name: 'comment', sort: ''},
                {title: updateDateColumnName, name: 'createdDate', sort: 'DESC'},
                {title: updateStateColumnName, name: 'status', sort: ''}
              ];
              observer.complete();
            });
          });
        });
      });
    });
  }

  protected initFilterPlaceholder() {
    this.translate.get('table.filter.all').subscribe(filterPlaceholder => {
      this.filterPlaceholder = filterPlaceholder;
    });
  }

  public findBySearch(search: SearchDto): Promise<any> {
    return this.service.getAllByProductId(this.productUid, search).then(pageResult => {
      this.length = pageResult.totalElements;
      this.totalPages = pageResult.totalPages;
      this.rows = this.reduceData(pageResult.content);
    });
  }

  protected reduceData(rows: Array<UpdateDto>): Array<any> {
    const reducedData = [];
    rows.forEach(update => {
      this.translate.get('update.status.' + update.status.toLowerCase()).subscribe(translatedStatus => {
        reducedData.push({
          uid: update.uid,
          name: this.shortenStringPipe.transform(update.name, 15),
          comment: this.shortenStringPipe.transform(update.comment, 15),
          status: this.getStatusStyle(update.status, translatedStatus),
          createdDate: this.datePipe.transform(update.createdDate, 'dd/MM/yyyy')
        });
      });
    });
    return reducedData;
  }

  private getStatusStyle(status: string, translatedStatus: string): string {
    switch (status) {
      case 'ERROR':
        return '<div class="text-danger"><i class="fa fa-exclamation-triangle"></i>&nbsp;' + translatedStatus + '</div>';
      case 'SUSPENDED':
        return '<div class="text-danger"><i class="fa fa-stop"></i>&nbsp;' + translatedStatus + '</div>';
      default:
        return translatedStatus;
    }
  }

}
