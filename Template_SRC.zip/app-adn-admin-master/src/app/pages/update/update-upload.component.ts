import {environment} from '../../../environments/environment';
import {Component, ElementRef, HostBinding, HostListener, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {UploadItem, UploadState, UploadxOptions} from '../../components/ngx-uploadx/interfaces';
import {UploadxService} from '../../components/ngx-uploadx/uploadx.service';
import {BsModalService} from 'ngx-bootstrap/modal';
import {ConfirmModalComponent} from '../../components/modal/confirm/confirm-modal.component';
import {ModalOptions} from 'ngx-bootstrap';
import {AuthenticationService} from '../../services/authentication.service';
import {ConfirmDeactivateComponent} from '../../interceptor/confirm-deactivate.interceptor';
import {UploadService} from '../../services/upload.service';
import {ActivatedRoute, Router} from '@angular/router';
import {UpdateDto} from '../../model/update/update-dto';
import {Subscription} from 'rxjs/internal/Subscription';
import {UploadFile} from '../../model/upload/UploadFile';
import {ToasterService} from '../../services/toaster.service';

@Component({
  selector: 'app-update-upload',
  templateUrl: './update-upload.component.html'
})
export class UpdateUploadComponent implements OnInit, OnDestroy, ConfirmDeactivateComponent {
  @HostBinding('class') cssClass = 'd-flex h-100 justify-content-center';

  @ViewChild('inputHashElement') inputHashElementRef: ElementRef;
  @ViewChild('inputUncompressedSizeElement') inputUncompressedSizeElementRef: ElementRef;
  @ViewChild('inputFileElement') inputFileElementRef: ElementRef;

  private authenticationToken = 'authenticationToken';

  update: UpdateDto;
  pauseResumeLabel = 'Pause';
  responseSuccess: string;
  responseError: string;

  profiles: string[];
  previousUploadUid: string;
  previousUploadFileName: string;

  hashType: string;
  hashValue: string;

  uncompressedSizeValue: string;

  isAllInputDisabled = false;
  isUploadDisabled = true;
  isGoToProductDisabled = false;
  isButtonPauseResumeDisabled = true;
  isButtonCancelDisabled = true;

  subscriber: Subscription;
  uploadFile: UploadFile;
  options: UploadxOptions = {
    concurrency: 1,
    allowedTypes: '*',
    autoUpload: false,
    chunkSize: 1024 * 256 * 8,
    /*headers: {
      'x-upload-checksum': '',
      'x-upload-uid': '',
      'x-upload-previous-file-uid': '',
      'x-upload-profiles': '',
      'x-upload-uncompressed-length': '',
    }*/
  };

  progressBarClass = 'info';

  @HostListener('window:beforeunload', ['$event'])
  public beforeUnloadHandler($event) {
    if (this.shouldNotDeactivate()) {
      $event.returnValue = 'Are you sure?';
    }

    // Action done if the user decide to not leave the page
    setTimeout(() => { this.continueAction(); }, 1000);
  }

  shouldNotDeactivate() {
    return this.uploadFile
      && this.uploadFile.status !== 'cancelled'
      && this.uploadFile.status !== 'complete'
      && this.uploadFile.status !== 'error';
  }

  getConfirmDeactivateMessage() {
    return 'Are you sure?';
  }

  deactivateAction() {
    const uploadId = this.uploadFile.uploadId;
    if (this.uploadFile.status !== 'paused' && this.uploadFile.status !== 'cancelled') {
      this.uploadX.control({action: 'cancel', uploadId});
    } else {
      this.uploadFile.status = 'cancelled';
    }
    this.sendCancel(uploadId);
  }

  continueAction() {
    const uploadId = this.uploadFile.uploadId;
    if (this.uploadFile.status !== 'paused' && this.uploadFile.status !== 'cancelled') {
      this.uploadX.control({action: 'pause', uploadId});
    }
    this.uploadService.pauseResumeUpload(uploadId, 'resume').then(() => {
      this.uploadX.control({action: 'upload', uploadId});
    }, () => {
      this.updateStatus('error');
    });
  }

  constructor(private authService: AuthenticationService,
              private uploadX: UploadxService,
              private modalService: BsModalService,
              private uploadService: UploadService,
              private route: ActivatedRoute,
              private router: Router,
              private toastr: ToasterService) {
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      const updateUid = params['updateUid'];
      if (updateUid) {
        this.previousUploadUid = params['uploadUid'];
        this.uploadService.checkUpdate(updateUid, this.previousUploadUid).then(res => {
          // Remove updateFileUid from url if the corresponding updateFile is not in update file list
          if (this.previousUploadUid && !res.value.updateFile) {
            this.router.navigate(['/upload/' + res.value.update.uid]);
          }

          this.update = res.value.update;
          if (res.value.updateFile) {
            this.previousUploadFileName = res.value.updateFile.name;
            this.profiles = res.value.updateFile.profiles;
          }

          if (res.messages.length > 0) {
            res.messages.push('modal.upload.check');
            const modalOptions = new ModalOptions();
            modalOptions.initialState = {
              'confirmMessageKey': res.messages,
            };
            const bsModalRef = this.modalService.show(ConfirmModalComponent, modalOptions);
            bsModalRef.content.onClose.subscribe(isConfirm => {
              if (isConfirm) {
                this.initUploadX(updateUid);
              } else {
                this.router.navigate(['/product', {uid: this.update.productUid}]);
              }
            });
          } else {
            this.initUploadX(updateUid);
          }
        });
      }
    });
  }

  ngOnDestroy() {
    this.uploadX['queue'].length = 0;
    if (this.subscriber) {
      this.subscriber.unsubscribe();
    }
  }

  private initUploadX(updateUid: string) {
    this.options.url = environment.serverUrl + '/upload/register/' + updateUid;
    this.options.token = this.authService.getToken();
    const uploadsProgress = this.uploadX.init(this.options);
    this.subscriber = uploadsProgress.subscribe((state: UploadState) => this.processState(state));
  }

  private processState(state: UploadState) {
    switch (state.status) {
      case 'added':
        this.uploadFile = new UploadFile(state);
        this.uploadFile.progress = 0;
        var itemOptions;
        if (this.uncompressedSizeValue != null) {
          itemOptions = {
            headers: {
              'x-upload-checksum': this.hashValue,
              'x-upload-uid': state.uploadId,
              'x-upload-previous-file-uid': this.previousUploadUid,
              'x-upload-profiles': this.profiles.toString(),
              'x-upload-uncompressed-length': this.uncompressedSizeValue
            }
          };
        } else {
          itemOptions = {
            headers: {
              'x-upload-checksum': this.hashValue,
              'x-upload-uid': state.uploadId,
              'x-upload-previous-file-uid': this.previousUploadUid,
              'x-upload-profiles': this.profiles.toString()
            }
          };
        }
        this.uploadX.control({action: 'upload', itemOptions: itemOptions, uploadId: state.uploadId});
        break;
      case 'cancelled':
      case 'paused':
      case 'complete':
      case 'error':
      case 'queue':
      case 'uploading':
        this.updateUpload(state);
        break;
    }
  }

  pauseResume(uploadId: string) {
    this.uploadService.pauseResumeUpload(uploadId, this.pauseResumeLabel.toLowerCase()).then(() => {
      if (this.pauseResumeLabel === 'Pause') {
        this.uploadX.control({action: 'pause', uploadId});
        this.pauseResumeLabel = 'Resume';
      } else if (this.pauseResumeLabel === 'Resume') {
        this.uploadX.control({action: 'upload', uploadId});
        this.pauseResumeLabel = 'Pause';
      }
    }, err => {
      this.updateStatus('error');
      console.log(err);
    });
  }

  cancel(uploadId: string) {
    this.uploadService.pauseResumeUpload(uploadId, 'pause').then(() => {
      if (this.uploadFile.status !== 'paused' && this.uploadFile.status !== 'cancelled') {
        this.uploadX.control({action: 'pause', uploadId});
      }
      const modalOptions = new ModalOptions();
      modalOptions.backdrop = 'static';
      modalOptions.keyboard = false;
      modalOptions.initialState = {
        'confirmMessageKey': 'modal.upload.cancel',
        'confirmMessageValue': this.uploadFile.name,
        'confirmIcon': 'check',
        'confirmButton': 'button.yes',
        'confirmCancelIcon': 'ban',
        'confirmCancelButton': 'button.no'
      };
      const bsModalRef = this.modalService.show(ConfirmModalComponent, modalOptions);
      bsModalRef.content.onClose.subscribe(isCancel => {
        if (isCancel) {
          this.sendCancel(uploadId);
        } else {
          this.uploadService.pauseResumeUpload(uploadId, 'resume').then(() => {
            this.uploadX.control({action: 'upload', uploadId});
          }, () => {
            this.updateStatus('error');
          });
        }
      });
    }, () => {
      this.updateStatus('error');
    });
  }

  gotoProduct() {
    this.router.navigate(['/product', {uid: this.update.productUid}]);
  }

  private sendCancel(uploadId: string) {
    this.uploadX['queue'].length = 0;
    this.uploadService.cancelUpload(uploadId).then(res => {
      this.updateStatus('cancelled');
      console.log(res);
    }, err => {
      console.log(err);
    });
  }

  private updateUpload(state: UploadState) {
    if (state.status === 'error') {
      this.responseSuccess = null;
      this.responseError = state.response.message;
    } else if (state.status === 'complete') {
      this.responseSuccess = 'success.upload';
      this.responseError = null;
    } else {
      this.responseSuccess = null;
      this.responseError = null;
    }
    this.uploadFile.setState(state);
    if (this.uploadFile.progress === 100 && state.status === 'uploading') {
      this.updateStatus('checksum.server');
    } else {
      this.updateStatus(state.status);
    }
  }

  private updateStatus(status: string) {
    this.uploadFile.status = status;
    this.setProgressBarStatus(this.uploadFile.status);
    this.setInputDisabled(this.uploadFile.status);

    if (this.isUploadFileInEndState()) {
      this.inputFileElementRef.nativeElement.value = '';
    }
  }

  private isUploadFileInEndState(): boolean {
    return this.uploadFile.status === 'complete' || this.uploadFile.status === 'cancelled' || this.uploadFile.status === 'error';
  }

  private setProgressBarStatus(status: string) {
    switch (status) {
      case 'checksum.server':
        this.progressBarClass = 'progress-bar-animated progress-bar-striped';
        break;
      case 'added':
      case 'queue':
      case 'uploading':
        this.progressBarClass = 'progress-bar-animated progress-bar-striped bg-info';
        break;
      case 'complete':
        this.progressBarClass = 'progress-bar-striped bg-success';
        break;
      case 'cancelled':
        this.progressBarClass = 'progress-bar-striped bg-warning';
        break;
      case 'paused':
        this.progressBarClass = 'progress-bar-animated progress-bar-striped bg-warning';
        break;
      case 'error':
        this.progressBarClass = 'progress-bar-striped bg-danger';
        break;
    }
  }

  private setInputDisabled(status: string) {
    switch (status) {
      case 'checksum.server':
        this.isAllInputDisabled = true;
        this.isUploadDisabled = true;
        this.isGoToProductDisabled = true;
        this.isButtonPauseResumeDisabled = true;
        this.isButtonCancelDisabled = true;
        break;
      case 'added':
      case 'queue':
      case 'uploading':
      case 'paused':
        this.isAllInputDisabled = true;
        this.isUploadDisabled = true;
        this.isGoToProductDisabled = true;
        this.isButtonPauseResumeDisabled = false;
        this.isButtonCancelDisabled = false;
        break;
      case 'error':
      case 'cancelled':
        this.isAllInputDisabled = false;
        this.isUploadDisabled = false;
        this.isGoToProductDisabled = false;
        this.isButtonPauseResumeDisabled = true;
        this.isButtonCancelDisabled = true;
        break;
      case 'complete':
        this.isAllInputDisabled = true;
        this.isUploadDisabled = true;
        this.isGoToProductDisabled = false;
        this.isButtonPauseResumeDisabled = true;
        this.isButtonCancelDisabled = true;
        break;
    }
  }

  changeHashType(hashType: string) {
    this.hashType = hashType;
  }

  selectHashFile(event: any) {
    if (event.target.files.length !== 0) {
      const file = event.target.files[0];
      event.target.value = '';
      if (file.size > 1024) {
        this.toastr.error('error.upload.checksum.file.size');
      } else {
        const reader = new FileReader();
        reader.readAsText(file);
        reader.onload = () => {
          this.hashValue = reader.result;
          this.checkHashType();
        };
      }
    }
  }

  checkHashType() {
    this.hashValue = this.hashValue.toLowerCase();
    switch (this.hashValue.length) {
      case 32:
        this.changeHashType('md5');
        break;
      case 40:
        this.changeHashType('sha1');
        break;
      case 64:
        this.changeHashType('sha256');
        break;
      default:
        this.changeHashType('');
        break;
    }
    this.setUploadDisabled();
  }

  setUploadDisabled() {
    this.isUploadDisabled =
      !this.inputHashElementRef.nativeElement.validity.valid ||
      !this.inputUncompressedSizeElementRef.nativeElement.validity.valid ||
      !this.profiles || this.profiles.length === 0;
  }
}
