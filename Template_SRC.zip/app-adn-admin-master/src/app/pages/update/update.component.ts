import {Component, EventEmitter, HostBinding, Input, Output, ViewChild} from '@angular/core';
import {UpdateDto} from '../../model/update/update-dto';
import {UpdateDetailComponent} from './update-detail.component';
import {UpdateTableComponent} from './update-table.component';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
})
export class UpdateComponent {
  @HostBinding('class') cssClass = 'd-flex h-100';

  @ViewChild(UpdateTableComponent) updateTableComponentRef: UpdateTableComponent;
  @ViewChild(UpdateDetailComponent) updateDetailComponentRef: UpdateDetailComponent;

  @Input() productRight: string;

  private _productUid: string;
  uid: string;

  @Output() updateEvent: EventEmitter<void> = new EventEmitter();
  @Output() deleteEvent: EventEmitter<void> = new EventEmitter();

  constructor() {
  }

  @Input()
  set productUid(productUid: string) {
    this._productUid = productUid;
    this.uid = null;
    this.updateTableComponentRef.tableSelectedItems = [];
    this.updateDetailComponentRef.resetComponent();
  }

  get productUid() {
    return this._productUid;
  }

  selectUpdate(update: UpdateDto) {
    this.uid = update.uid;
  }

  onUpdateDetail(event: UpdateDto) {
    this.updateTableComponentRef.updateTable();
    this.updateEvent.emit();
  }

  onDeleteDetail() {
    this.updateTableComponentRef.updateTable();
    this.deleteEvent.emit();
  }
}
