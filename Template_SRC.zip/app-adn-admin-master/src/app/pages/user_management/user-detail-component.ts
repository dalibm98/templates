import {Component, OnInit} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {BsModalService} from 'ngx-bootstrap/modal';
import {ModalOptions} from 'ngx-bootstrap';

import {AbstractDetailComponent} from '../../components/detail/abstract-detail.component';
import {GroupWithUserDto} from '../../model/group/group-with-user-dto';
import {GroupDetailComponent} from '../group_management/group-detail.component';
import {ProductService} from '../../services/product.service';
import {GroupService} from '../../services/group.service';
import {UserService} from '../../services/user.service';
import {GroupDto} from '../../model/group/group-dto';
import {UserDto} from '../../model/user/user-dto';
import {AccountService} from '../../services/account.service';
import {SelectItemsByTableModalComponent} from '../../components/modal/select-items/select-items-by-table-modal.component';
import {GroupTableComponent} from '../group_management/group-table.component';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
})
export class UserDetailComponent extends AbstractDetailComponent<UserDto, UserService> implements OnInit {

  langList: Array<string>;
  groups: Array<GroupWithUserDto>;
  authorities = ['ROLE_USER', 'ROLE_ADMIN'];
  current_authority: string;

  constructor(private userService: UserService,
              protected modalService: BsModalService,
              private groupService: GroupService,
              private productService: ProductService,
              private translate: TranslateService,
              private accountService: AccountService) {
    super(UserDto, userService, modalService);
  }

  ngOnInit(): void {
    this.groupService.getAll().then(res => {
      this.groups = res;
    });
    this.langList = this.translate.getLangs();
  }

  initCurrentDetail() {
    const temp_authorities = this.originDetail.authorities;
    if (temp_authorities.length > 0) {
      this.current_authority = this.originDetail.authorities[0];
    }
    if (!this.originDetail.groups) {
      this.originDetail.groups = [];
    }
    this.currentDetail = JSON.parse(JSON.stringify(this.originDetail));
  }

  protected preSave() {
    this.currentDetail.authorities = [this.current_authority];
  }

  protected preNew() {
    this.current_authority = null;
  }

  protected preDelete() {
    this.current_authority = null;
  }

  addGroups() {
    const modalOptions = new ModalOptions();

    modalOptions.initialState = {
      'inputSelectedList': this.currentDetail.groups,
      'inputBindLabel': 'name',
      'inputTableComponentToCreate': GroupTableComponent,
      'inputIsCreateNeeded': true,
      'inputCreatePlaceholder': 'modal.create.group',
      'inputCreateButtonLabel': 'button.create.group',
      'inputCreateComponentToCreate': GroupDetailComponent,
      'inputCreateElementClass': GroupWithUserDto,
      'inputCreateElementService': GroupService
    };
    modalOptions.class = 'modal-dialog modal-lg';
    const bsModalRef = this.modalService.show(SelectItemsByTableModalComponent, modalOptions);
    bsModalRef.content.onClose.subscribe(result => {
      if (result) {
        this.currentDetail.groups = result;
      }
    });
  }

  removeGroup(group: GroupDto) {
    const groups = this.currentDetail.groups;
    const groupIndex = groups.indexOf(group);
    if (groupIndex !== -1) {
      groups.splice(groupIndex, 1);
    }
  }

  renewActivation() {
    this.accountService.renewActivationEmail(this.originDetail.uid);
  }
}
