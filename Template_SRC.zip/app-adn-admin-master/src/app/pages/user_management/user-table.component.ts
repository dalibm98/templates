import {AbstractTableComponent} from '../../components/table/abstract-table.component';
import {UserService} from '../../services/user.service';
import {Component} from '@angular/core';
import {UserDto} from '../../model/user/user-dto';
import {TranslateService} from '@ngx-translate/core';
import {Observable} from 'rxjs/internal/Observable';
import {Observer} from 'rxjs/internal/types';

@Component({
  selector: 'app-user-table',
  templateUrl: '../../components/table/table.component.html',
})
export class UserTableComponent extends AbstractTableComponent<UserDto, UserService> {

  constructor(protected userService: UserService, private translate: TranslateService) {
    super(userService);
  }

  protected initTableColumns(): Observable<void> {
    return Observable.create((observer: Observer<void>) => {
      this.translate.get('user.login').subscribe(loginColumnName => {
        this.translate.get('user.first_name').subscribe(firstNameColumnName => {
          this.translate.get('user.last_name').subscribe(lastNameColumnName => {
            this.translate.get('user.email').subscribe(emailColumnName => {
              this.columns = [
                {title: loginColumnName, name: 'login'},
                {title: firstNameColumnName, name: 'firstName'},
                {title: lastNameColumnName, name: 'lastName'},
                {title: emailColumnName, name: 'email'},
              ];
              observer.complete();
            });
          });
        });
      });
    });
  }

  protected initFilterPlaceholder() {
    this.translate.get('table.filter.all').subscribe(filterPlaceholder => {
      this.filterPlaceholder = filterPlaceholder;
    });
  }

  protected reduceData(rows: Array<UserDto>): Array<any> {
    return rows;
  }

}
