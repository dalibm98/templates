import {Component, HostBinding, ViewChild} from '@angular/core';

import {UserDto} from '../../model/user/user-dto';
import {UserTableComponent} from './user-table.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
})
export class UserComponent {
  @HostBinding('class') cssClass = 'd-flex h-100';

  @ViewChild(UserTableComponent) userTableComponentRef: UserTableComponent;

  uid: string;

  constructor() {
  }

  selectUser(user: UserDto) {
    this.uid = user.uid;
  }

  onNewDetail() {
    this.uid = null;
    this.userTableComponentRef.highlightSelectedRow(null);
  }

  onUpdateDetail(event: UserDto) {
    this.userTableComponentRef.tableSelectedItems = [event];
    this.userTableComponentRef.updateTable();
  }

  onDeleteDetail() {
    this.userTableComponentRef.updateTable();
  }

}
