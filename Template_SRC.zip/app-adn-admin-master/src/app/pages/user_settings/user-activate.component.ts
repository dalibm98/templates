import {Component, OnInit} from '@angular/core';

import {ActivatedRoute, Router} from '@angular/router';
import {AccountService} from '../../services/account.service';

@Component({
  selector: 'app-activate',
  templateUrl: './user-activate.component.html',
  // styleUrls: ['./activate.component.scss']
})
export class UserActivateComponent implements OnInit {
  error: string;
  success: string;
  resetKey: string;
  passwordChanged = false;

  constructor(private route: ActivatedRoute, private router: Router, private activateService: AccountService) {
  }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.activateService.activateAccount(params['key']).then(resetKey => {
        this.error = null;
        this.success = 'OK';
        this.resetKey = resetKey;
      }, () => {
        this.success = null;
        this.error = 'ERROR';
      });
    });
  }

  onPasswordChanged() {
    this.passwordChanged = true;
  }

  goToLogin() {
    this.router.navigate(['login']);
  }
}
