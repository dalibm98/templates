import {Component} from '@angular/core';
import {AccountService} from '../../services/account.service';

@Component({
  selector: 'app-user-password',
  templateUrl: './user-forgot-password.component.html',
})
export class UserForgotPasswordComponent {

  userEmail;
  emailSent: boolean;

  constructor(private accountService: AccountService) {
  }

  resetPassword() {
    this.accountService.resetPassword(this.userEmail).then(() => {
      this.emailSent = true;
    });
  }
}
