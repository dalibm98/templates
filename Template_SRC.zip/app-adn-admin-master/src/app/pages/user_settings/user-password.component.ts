import {Component} from '@angular/core';

@Component({
  selector: 'app-user-password',
  templateUrl: './user-password.component.html',
})
export class UserPasswordComponent {

  constructor() {
  }

}
