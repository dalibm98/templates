import {Component, OnInit} from '@angular/core';

import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-user-reset-password',
  templateUrl: './user-reset-password.component.html',
})
export class UserResetPasswordComponent implements OnInit {
  resetKey: string;
  passwordChanged = false;

  constructor(private route: ActivatedRoute, private router: Router) {
  }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      if (params['key']) {
        this.resetKey = params['key'];
      }
    });
  }

  onPasswordChanged(event) {
    this.passwordChanged = event;
  }

  goToLogin() {
    this.router.navigate(['login']);
  }
}
