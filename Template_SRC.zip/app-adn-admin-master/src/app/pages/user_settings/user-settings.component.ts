import {Component, OnInit} from '@angular/core';
import {UserService} from '../../services/user.service';
import {CurrentUserService} from '../../services/current-user.service';
import {UserDto} from '../../model/user/user-dto';
import {TranslateService} from '@ngx-translate/core';
import {CurrentUserDto} from '../../model/user/current-user-dto';

@Component({
  selector: 'app-user-settings',
  templateUrl: './user-settings.component.html',
})
export class UserSettingsComponent implements OnInit {

  currentUser: CurrentUserDto;
  langList: Array<string>;

  success;
  error;

  constructor(private userService: UserService,
              private currentUserService: CurrentUserService,
              private translate: TranslateService) {
    this.currentUser = new UserDto();
  }

  ngOnInit(): void {
    this.currentUserService.getUser().then(user => this.currentUser = user);
    this.langList = this.translate.getLangs();
  }

  updateCurrentUser(): void {
    this.userService.updateCurrentUser(this.currentUser).then(() => {
      this.currentUserService.store(this.currentUser);
      this.success = 'OK';
    }, () => {
      this.error = 'NOK';
    });
  }
}
