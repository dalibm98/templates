import {Component, HostBinding, Input} from '@angular/core';
import {VersionService} from '../../../services/version.service';
import {VersionForGraphDto, VersionGraphDto} from '../../../model/version/version-graph-dto';
import {VersionDto} from '../../../model/version/version-dto';
import * as shape from 'd3-shape';

@Component({
  selector: 'app-version-graph',
  templateUrl: './version-graph.component.html',
  styleUrls: ['./version-graph.component.scss']
})
export class VersionGraphComponent {
  @HostBinding('class') cssClass = 'd-flex h-100 overflow-hidden';

  private _productUid: string;
  isRefresh = false;

  @Input()
  set productUid(productUid: string) {
    this._productUid = productUid;
    this.updateGraph();
  }

  versionGraph: VersionGraphDto;

  nodes = [];
  links = [];
  curve = shape.curveLinear;
  colorScheme = {
    name: 'adn',
    selectable: true,
    group: 'Ordinal',
    domain: [
      '#546472', '#546472', '#939598', '#d4d5d6', '#bdd248'
    ]
  };

  constructor(private versionService: VersionService) {
  }

  updateGraph() {
    this.isRefresh = true;
    this.versionService.getGraphForProduct(this._productUid).then(res => {
      this.versionGraph = res;
      this.setNodesAndLinks();
      this.isRefresh = false;
    });
  }

  private setNodesAndLinks() {
    this.nodes = [];
    this.links = [];
    this.versionGraph.links.forEach(link => {
      this.addNodeIfNotPresent(link.fromVersion);
      this.addNodeIfNotPresent(link.toVersion);
      this.links.push({source: link.fromVersion.uid, target: link.toVersion.uid});
    });
  }

  private addNodeIfNotPresent(version: VersionForGraphDto) {
    const node = {id: version.uid, label: version.name, tooltip: version.description, color: this.getColorFromStatus(version.status)};
    if (!this.nodes.find(nd => nd.id === node.id)) {
      this.nodes.push(node);
    }
  }

  private getColorFromStatus(status: string) {
    switch (status) {
      case 'PENDING':
        return '#ffffff';
      case 'ERROR':
        return '#d50f25';
      case 'UNPUBLISHED':
        return '#d4d5d6';
      case 'IN_TEST':
        return '#939598';
      case 'FIELD_TEST':
        return '#546472';
      case 'PUBLISHED':
        return '#bdd248';
      case 'SUSPENDED':
        return '#d4565d';
      default:
        return '#bdd248';
    }
  }
}
