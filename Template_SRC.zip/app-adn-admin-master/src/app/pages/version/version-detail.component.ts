import {AbstractDetailComponent} from '../../components/detail/abstract-detail.component';
import {VersionService} from '../../services/version.service';
import {Component, Input} from '@angular/core';
import {VersionDto} from '../../model/version/version-dto';
import {BsModalService} from 'ngx-bootstrap/modal';
import {VersionWithAssociatedUpdatesDto} from '../../model/version/version-with-associated-updates-dto';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-version-detail',
  templateUrl: './version-detail.component.html'
})
export class VersionDetailComponent extends AbstractDetailComponent<VersionWithAssociatedUpdatesDto, VersionService> {

  @Input() private productUid: string;
  @Input() private productRight = 'READER';

  constructor(protected versionService: VersionService,
              protected modalService: BsModalService,
              protected translate: TranslateService) {
    super(VersionDto, versionService, modalService);
  }

  public resetComponent() {
    this.originDetail = null;
    this.currentDetail = null;
  }

  protected initCurrentDetail() {
    this.currentDetail = JSON.parse(JSON.stringify(this.originDetail));
  }

  protected preSave() {
    this.currentDetail.productUid = this.productUid;
  }

}
