import {Component, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {DatePipe} from '@angular/common';

import {AbstractTableComponent} from '../../components/table/abstract-table.component';
import {Observable} from 'rxjs/internal/Observable';
import {Observer} from 'rxjs/internal/types';
import {VersionService} from '../../services/version.service';
import {VersionDto} from '../../model/version/version-dto';
import {SearchDto} from '../../model/search/search-dto';
import {ShortenStringPipe} from '../../pipes/shorten-string.pipe';

@Component({
  selector: 'app-version-table',
  templateUrl: '../../components/table/table.component.html',
})
export class VersionTableComponent extends AbstractTableComponent<VersionDto, VersionService> {

  private _productUid: string;

  constructor(protected versionService: VersionService,
              private translate: TranslateService,
              private datePipe: DatePipe,
              private shortenStringPipe: ShortenStringPipe) {
    super(versionService);
  }

  @Input()
  set productUid(productUid: string) {
    if (!this._productUid) { // this.onChangeTable() automatically called here
      this._productUid = productUid;
    } else {
      this._productUid = productUid;
      this.onChangeTable(this.config);
    }
  }

  get productUid() {
    return this._productUid;
  }

  protected initTableColumns(): Observable<void> {
    return Observable.create((observer: Observer<void>) => {
      this.translate.get('global.name').subscribe(versionNameColumnName => {
        this.translate.get('global.comment').subscribe(versionCommentColumnName => {
          this.translate.get('global.creation_date').subscribe(versionDateColumnName => {
            this.columns = [
              {title: versionNameColumnName, name: 'name', sort: ''},
              {title: versionCommentColumnName, name: 'comment', sort: ''},
              {title: versionDateColumnName, name: 'createdDate', sort: 'DESC'},
            ];
            observer.complete();
          });
        });
      });
    });
  }

  protected initFilterPlaceholder() {
    this.translate.get('table.filter.all').subscribe(filterPlaceholder => {
      this.filterPlaceholder = filterPlaceholder;
    });
  }

  protected findBySearch(search: SearchDto): Promise<any> {
    return this.service.getAllByProductId(this.productUid, search).then(pageResult => {
      this.length = pageResult.totalElements;
      this.totalPages = pageResult.totalPages;
      this.rows = this.reduceData(pageResult.content);
    });
  }

  protected reduceData(rows: Array<VersionDto>): Array<any> {
    const reducedData = [];
    rows.forEach(version => {
      reducedData.push({
        uid: version.uid,
        name: version.name,
        comment: this.shortenStringPipe.transform(version.comment, 15),
        createdDate: this.datePipe.transform(version.createdDate, 'dd/MM/yyyy')
      });
    });
    return reducedData;
  }

  protected expandData(rows: Array<any>): Array<VersionDto> {
    const expandedData = [];
    rows.forEach(version => {
      expandedData.push({
        uid: version.uid,
        name: version.name,
        comment: version.comment,
      });
    });
    return expandedData;
  }

}
