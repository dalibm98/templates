import {Component, EventEmitter, HostBinding, Input, Output, ViewChild} from '@angular/core';
import {VersionDto} from '../../model/version/version-dto';
import {VersionWithAssociatedUpdatesDto} from '../../model/version/version-with-associated-updates-dto';
import {VersionDetailComponent} from './version-detail.component';
import {VersionTableComponent} from './version-table.component';

@Component({
  selector: 'app-version',
  templateUrl: './version.component.html',
})
export class VersionComponent {
  @HostBinding('class') cssClass = 'd-flex h-100';

  @ViewChild(VersionTableComponent) versionTableComponentRef: VersionTableComponent;
  @ViewChild(VersionDetailComponent) versionDetailComponentRef: VersionDetailComponent;

  @Input() productRight: string;

  @Output() private updateDeleteEvent: EventEmitter<void> = new EventEmitter();

  _productUid: string;
  uid: string;

  constructor() {
  }

  @Input()
  set productUid(productUid: string) {
    this._productUid = productUid;
    this.uid = null;
    this.versionTableComponentRef.tableSelectedItems = [];
    this.versionDetailComponentRef.resetComponent();
  }

  get productUid() {
    return this._productUid;
  }

  selectVersion(version: VersionDto) {
    this.uid = version.uid;
  }

  newVersion() {
    this.versionDetailComponentRef.new(null);
    this.versionTableComponentRef.highlightSelectedRow(null);
  }

  onNewDetail() {
    this.uid = null;
  }

  onUpdateDetail(event: VersionWithAssociatedUpdatesDto) {
    this.versionTableComponentRef.tableSelectedItems = [event];
    this.versionTableComponentRef.updateTable();
    this.updateDeleteEvent.emit();
  }

  onDeleteDetail() {
    this.versionTableComponentRef.updateTable();
    this.updateDeleteEvent.emit();
  }
}
