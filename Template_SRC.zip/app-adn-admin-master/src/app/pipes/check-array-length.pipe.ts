import {Pipe, PipeTransform} from '@angular/core';

@Pipe({ name: 'checkArrayLength' })
export class CheckArrayLengthPipe implements PipeTransform {

  transform(array: any) {
    return array && (array instanceof Array ? array.length > 0 : Object.keys(array).length > 0);
  }

}
