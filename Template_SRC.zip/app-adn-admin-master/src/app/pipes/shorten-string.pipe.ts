import {Pipe, PipeTransform} from '@angular/core';

@Pipe({ name: 'shortenString' })
export class ShortenStringPipe implements PipeTransform {

  transform(value: string, maxLength: number) {
    let shortenString = value;
    if (shortenString && shortenString.length > maxLength) {
      shortenString = shortenString.substr(0, maxLength) + '...';
    }
    return shortenString;
  }

}
