import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'formatSize'})
export class SizePipe implements PipeTransform {

  labels = ['o', 'Ko', 'Mo', 'Go', 'To'];

  transform(value: number, suffix?: string) {
    if (!suffix) {
      suffix = '';
    }

    let index = 0;
    while (value >= 1024) {
      if ((index + 1) >= this.labels.length) {
        break;
      }
      value /= 1024;
      index++;
    }

    return value.toFixed(2) + ' ' + this.labels[index] + suffix;
  }

}
