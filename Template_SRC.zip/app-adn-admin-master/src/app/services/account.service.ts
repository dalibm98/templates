import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {KeyAndPassword} from '../model/account/key-and-password';

@Injectable()
export class AccountService {
  private baseUrl = environment.serverPublicUrl + '/account';
  private activateUrl = this.baseUrl + '/activate';
  private renewActivationUrl = this.baseUrl + '/renew';
  private initPasswordUrl = this.baseUrl + '/init-password';
  private changePasswordUrl = this.baseUrl + '/change-password';
  private resetPasswordUrl = this.baseUrl + '/reset-password';

  constructor(private http: HttpClient) {
  }

  activateAccount(key: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(this.activateUrl, key, {responseType: 'text'}).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  renewActivationEmail(userUid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(this.renewActivationUrl, userUid).subscribe(res => resolve(res), err => reject(err));
    });
  }

  savePassword(newPassword: string | KeyAndPassword) {
    if (typeof newPassword === 'string') {
      return this.changePassword(newPassword);
    } else {
      return this.initPassword(newPassword);
    }
  }

  initPassword(keyAndPassword: KeyAndPassword): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(this.initPasswordUrl, keyAndPassword).subscribe(res => resolve(res), err => reject(err));
    });
  }

  changePassword(newPassword: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(this.changePasswordUrl, newPassword).subscribe(res => resolve(res), err => reject(err));
    });
  }

  resetPassword(email: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(this.resetPasswordUrl, email).subscribe(res => resolve(res), err => reject(err));
    });
  }
}
