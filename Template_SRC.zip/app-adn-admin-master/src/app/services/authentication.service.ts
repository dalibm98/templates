import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Login} from '../model/authentication/login';
import {environment} from '../../environments/environment';
import {LocalStorageService, SessionStorageService} from 'ngx-webstorage';

@Injectable()
export class AuthenticationService {

  private authUrl = environment.serverPublicUrl + '/auth/';

  constructor(private http: HttpClient,
              private $localStorage: LocalStorageService,
              private $sessionStorage: SessionStorageService) {
  }

  getToken() {
    return this.$localStorage.retrieve('authenticationToken') || this.$sessionStorage.retrieve('authenticationToken');
  }

  login(username: string, password: string, rememberMe: boolean): any {
    const credentials: Login = new Login(username, password, rememberMe);

    return new Promise((resolve, reject) => {
      this.http.post(this.authUrl, credentials, {observe: 'response'})
        .subscribe(res => {
          const bearerToken = res.headers.get('Authorization');
          if (bearerToken && bearerToken.slice(0, 7) === 'Bearer ') {
            const jwt = bearerToken.slice(7, bearerToken.length);
            this.storeAuthenticationToken(jwt, credentials.rememberMe);
            resolve(res.body);
          }
        }, err => {
          reject(err);
        });
    });
  }

  getCurrentUser(): any {
    return new Promise((resolve, reject) => {
      this.http.get(this.authUrl)
        .subscribe(res => {
          resolve(res);
        }, err => {
          reject(err);
        });
    });
  }

  storeAuthenticationToken(jwt, rememberMe) {
    if (rememberMe) {
      this.$localStorage.store('authenticationToken', jwt);
    } else {
      this.$sessionStorage.store('authenticationToken', jwt);
    }
  }

  logout(): Promise<void> {
    return new Promise<void>(resolve => {
      this.$localStorage.clear('authenticationToken');
      this.$sessionStorage.clear('authenticationToken');
      resolve();
    });
  }
}
