import {AbstractCrudService} from './abstract-crud.service';
import {SearchDto} from '../../model/search/search-dto';

export abstract class AbstractCrudWithSearchService<T> extends AbstractCrudService<T> {
  abstract findBySearch(search: SearchDto);
}
