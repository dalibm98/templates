export abstract class AbstractCrudService<T> {
  abstract getAll(): Promise<any>;
  abstract getByUid(uid: string): Promise<any>;
  abstract save(T): Promise<any>;
  abstract delete(T): Promise<any>;
}
