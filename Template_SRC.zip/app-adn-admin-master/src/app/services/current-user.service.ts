import {Injectable} from '@angular/core';
import {AuthenticationService} from './authentication.service';
import {CurrentUserDto} from '../model/user/current-user-dto';
import {TranslateService} from '@ngx-translate/core';

@Injectable()
export class CurrentUserService {
  public user: CurrentUserDto;

  constructor(private authService: AuthenticationService,
              private translate: TranslateService) {
    this.user = new CurrentUserDto();
  }

  getUser(): Promise<CurrentUserDto> {
    return new Promise<CurrentUserDto>((resolve, reject) => {
      if (!this.user.id) {
        this.authService.getCurrentUser()
          .then(res => {
            this.store(res);
            resolve(this.clone());
          }, err => {
            reject(err);
          });
      } else {
        resolve(this.clone());
      }
    });
  }

  store(res: CurrentUserDto) {
    this.user = JSON.parse(JSON.stringify(res));
    this.translate.use(this.user.langKey);
  }

  clear() {
    this.user = new CurrentUserDto();
  }

  isAdmin(): boolean {
    return this.user.authorities && this.user.authorities.indexOf('ROLE_ADMIN') !== -1;
  }

  private clone(): CurrentUserDto {
    return JSON.parse(JSON.stringify(this.user));
  }
}
