import {Injectable} from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {AbstractCrudService} from './crud/abstract-crud.service';
import {ProductDtoWithSimpleRights} from '../model/product/product-dto-with-simple-rights';
import {ProductDto} from '../model/product/product-dto';

@Injectable()
export class ProductService extends AbstractCrudService<ProductDto> {
  private productUrl = environment.serverUrl + '/product/';
  private allProductsUrl = this.productUrl + 'all';
  private getSimpleProductWithRightByUidUrl = this.productUrl + 'simple/';
  private getProductByUidUrl = this.productUrl;
  private updateProductUrl = this.productUrl;
  private createProductUrl = this.productUrl;

  constructor(private http: HttpClient) {
    super();
  }

  /**
   * Get all products for current user
   * @returns {Promise<any>}
   */
  getAll(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(this.productUrl).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }


  /**
   * Get all products for all users
   * @returns {Promise<any>}
   */
  getAllProductsForAllUsers(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(this.allProductsUrl).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getSimpleProductWithRightByUid(uid: string): Promise<ProductDtoWithSimpleRights> {
    return new Promise((resolve, reject) => {
      this.http.get<ProductDtoWithSimpleRights>(this.getSimpleProductWithRightByUidUrl + uid)
        .subscribe(res => resolve(res), err => reject(err));
    });
  }

  getByUid(uid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(this.getProductByUidUrl + uid).subscribe(res => resolve(res), err => reject(err));
    });
  }

  save(product: ProductDto): Promise<any> {
    return new Promise((resolve, reject) => {
      if (product.uid) {
        this.http.put(this.updateProductUrl, product).subscribe(res => resolve(res), err => reject(err));
      } else {
        this.http.post(this.createProductUrl, product).subscribe(res => resolve(res), err => reject(err));
      }
    });
  }

  delete(T): Promise<any> {
    return undefined;
  }

}
