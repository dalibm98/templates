import {Injectable} from '@angular/core';
import {SessionStorageService} from 'ngx-webstorage';

@Injectable()
export class StateStorageService {
  constructor(private $sessionStorage: SessionStorageService) {
  }

  storeUrl(url: string) {
    this.$sessionStorage.store('previousUrl', url);
  }

  getUrl() {
    return this.$sessionStorage.retrieve('previousUrl');
  }

  clearUrl() {
    this.$sessionStorage.clear('previousUrl');
  }

  isUrl() {
    return !!this.getUrl();
  }
}
