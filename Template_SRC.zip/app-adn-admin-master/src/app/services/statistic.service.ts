import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';

import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable()
export class StatisticService {

  private statisticUrl = environment.serverUrl + '/statistic/';
  private stateUrl = this.statisticUrl + 'parkstate';
  private requestsUrl = this.statisticUrl + 'requestnumber';

  constructor(private http: HttpClient) {
  }

  public getParkStatByProduct(productCode: string, query: string, field: string, atDateEpochMilli: string) {
    return new Promise((resolve, reject) => {
      this.http.get(this.stateUrl
        + '?productcode=' + productCode
        + '&query=' + query
        + '&field=' + field
        + '&at=' + atDateEpochMilli)
        .subscribe(res => resolve(res), err => reject(err));
    });
  }

  public getNumberOfRequestsBetweenDates(productCode: string, query: string, fromDateEpochMilli: string, toDateEpochMilli: string, yField: string) {
    return new Promise((resolve, reject) => {
      this.http.get(this.requestsUrl
        + '?productcode=' + productCode
        + '&query=' + query
        + '&from=' + fromDateEpochMilli
        + '&to=' + toDateEpochMilli
        + '&yfield=' + yField)
        .subscribe(res => resolve(res), err => reject(err));
    });
  }

  public exportAsExcelFile(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = {Sheets: {'data': worksheet}, SheetNames: ['data']};
    XLSX.writeFile(workbook, excelFileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }
}
