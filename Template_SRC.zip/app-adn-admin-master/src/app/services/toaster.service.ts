import {ToastrService} from 'ngx-toastr';
import {TranslateService} from '@ngx-translate/core';
import {Injectable} from '@angular/core';

@Injectable()
export class ToasterService {
  constructor(private toastr: ToastrService, private translate: TranslateService) {
  }

  success(success: string | Array<string>, title?: string) {
    this.toast(success, 'success', title);
  }

  warning(warning: string | Array<string>, title?: string) {
    this.toast(warning, 'warning', title);
  }

  error(error: string | Array<string>, title?: string) {
    this.toast(error, 'error', title);
  }

  private toast(message: string | Array<string>, toastFunctionName, title?: string) {
    if (typeof message === 'string') {
      this.translate.get(message.trim()).subscribe(value => {
        this.toastr[toastFunctionName](value, title);
      }, () => {
        this.toastr[toastFunctionName](message, title);
      });
    } else if (message instanceof Array) {
      message.forEach(mess => {
        this.toast(mess, toastFunctionName);
      });
    }
  }

  errorWithParam(error: string | Array<string>, param: string | Array<string>, title?: string) {
    this.toastWithParam(error, param, 'error', title);
  }

  private toastWithParam(message: string | Array<string>, param: string | Array<string>, toastFunctionName, title?: string) {
    if (typeof message === 'string') {
      let translateParameter;
      if (param.indexOf(';') !== -1 && typeof param === 'string') {
        // JSON from server
        translateParameter = JSON.parse(param.replace(/;/g, ','));
      } else {
        translateParameter = {value: param};
      }
      this.translate.get(message.trim(), translateParameter).subscribe(msgValue => {
        this.toastr[toastFunctionName](msgValue, title);
      }, () => {
        this.toastr[toastFunctionName](message, title);
      });
    } else if (message instanceof Array) {
      message.forEach((mess, idx) => {
        this.toastWithParam(mess, param[idx], toastFunctionName);
      });
    }
  }
}
