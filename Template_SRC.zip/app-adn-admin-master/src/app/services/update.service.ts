import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {AbstractCrudWithSearchService} from './crud/abstract-crud-with-search.service';
import {SearchDto} from '../model/search/search-dto';
import {UpdateDto} from '../model/update/update-dto';
import {UpdateWithAssociatedVersionsDto} from '../model/update/update-with-associated-versions-dto';

@Injectable()
export class UpdateService extends AbstractCrudWithSearchService<UpdateDto> {

  private updateUrl = environment.serverUrl + '/update/';
  private suspendUrl = this.updateUrl + 'suspend/';

  constructor(private http: HttpClient) {
    super();
  }

  getAll(): Promise<any> {
    throw new Error('Not Implemented');
  }

  getAllByProductId(productUid: string, search: SearchDto): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(this.updateUrl + 'by-product/' + productUid, search).subscribe(res => resolve(res), err => reject(err));
    });
  }

  getByUid(uid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(this.updateUrl + uid).subscribe(res => resolve(res), err => reject(err));
    });
  }

  findBySearch(search: SearchDto) {
    throw new Error('Use getAllByProductId method instead');
  }

  save(update: UpdateWithAssociatedVersionsDto): Promise<any> {
    return new Promise((resolve, reject) => {
      if (update.uid) {
        this.http.put(this.updateUrl, update).subscribe(res => resolve(res), err => reject(err));
      } else {
        this.http.post(this.updateUrl, update).subscribe(res => resolve(res), err => reject(err));
      }
    });
  }

  delete(update: UpdateDto): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.delete(this.updateUrl + update.uid).subscribe(res => resolve(res), err => reject(err));
    });
  }

  updateStatus(uid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.patch(this.updateUrl + uid, null, {responseType: 'text'})
        .subscribe(res => resolve(res), err => reject(err));
    });
  }

  suspendUpdate(uid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.patch(this.suspendUrl + uid, null, {responseType: 'text'})
        .subscribe(res => resolve(res), err => reject(err));
    });
  }

}
