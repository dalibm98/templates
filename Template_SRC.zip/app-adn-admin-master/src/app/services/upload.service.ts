import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';

@Injectable()
export class UploadService {

  private checkUpdateUrl = environment.serverUrl + '/upload/check/';
  private uploadStatusUrl = environment.serverUrl + '/upload/status/';
  private uploadCancelUrl = environment.serverUrl + '/upload/cancel/';
  private uploadDeleteUrl = environment.serverUrl + '/upload/delete/';

  constructor(private http: HttpClient) {
  }

  checkUpdate(updateUid: string, uploadUid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      if (uploadUid) {
        this.http.get(this.checkUpdateUrl + updateUid + '/' + uploadUid).subscribe(res => resolve(res), err => reject(err));
      } else {
        this.http.get(this.checkUpdateUrl + updateUid).subscribe(res => resolve(res), err => reject(err));
      }
    });
  }

  pauseResumeUpload(uploadUid: string, status: string) {
    return new Promise((resolve, reject) => {
      this.http.patch(this.uploadStatusUrl + uploadUid, status).subscribe(res => resolve(res), err => reject(err));
    });
  }

  cancelUpload(uploadUid: string) {
    return new Promise((resolve, reject) => {
      this.http.delete(this.uploadCancelUrl + uploadUid).subscribe(res => resolve(res), err => reject(err));
    });
  }

  deleteUpload(updateFileUid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.delete(this.uploadDeleteUrl + updateFileUid).subscribe(res => resolve(res), err => reject(err));
    });
  }
}
