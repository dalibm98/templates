import {Injectable} from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {UserDto} from '../model/user/user-dto';
import {AbstractCrudWithSearchService} from './crud/abstract-crud-with-search.service';
import {SearchDto} from '../model/search/search-dto';
import {CurrentUserDto} from '../model/user/current-user-dto';

@Injectable()
export class UserService extends AbstractCrudWithSearchService<UserDto> {
  private userUrl = environment.serverUrl + '/user/';
  private getUserByUidUrl = this.userUrl + 'uid/';
  private getBySearchUrl = this.userUrl + 'search';
  private createUserUrl = this.userUrl;
  private updateUserUrl = this.userUrl;
  private updateCurrentUserUrl = this.userUrl + 'current';
  private deleteUserUrl = this.userUrl;

  constructor(private http: HttpClient) {
    super();
  }

  getAll(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(this.userUrl).subscribe(res => resolve(res), err => reject(err));
    });
  }

  getByUid(uid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(this.getUserByUidUrl + uid).subscribe(res => resolve(res), err => reject(err));
    });
  }

  findBySearch(search: SearchDto) {
    return new Promise((resolve, reject) => {
      this.http.post(this.getBySearchUrl, search).subscribe(res => resolve(res), err => reject(err));
    });
  }

  save(user: UserDto): Promise<any> {
    return new Promise((resolve, reject) => {
      if (user.uid) {
        this.http.put(this.updateUserUrl, user).subscribe(res => resolve(res), err => reject(err));
      } else {
        this.http.post(this.createUserUrl, user).subscribe(res => resolve(res), err => reject(err));
      }
    });
  }

  updateCurrentUser(user: CurrentUserDto): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.put(this.updateCurrentUserUrl, user).subscribe(res => resolve(res), err => reject(err));
    });
  }

  delete(user: UserDto): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.delete(this.deleteUserUrl + user.login).subscribe(res => resolve(res), err => reject(err));
    });
  }
}
