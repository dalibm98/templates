import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {VersionDto} from '../model/version/version-dto';
import {AbstractCrudWithSearchService} from './crud/abstract-crud-with-search.service';
import {SearchDto} from '../model/search/search-dto';

@Injectable()
export class VersionService extends AbstractCrudWithSearchService<VersionDto> {

  private versionUrl = environment.serverUrl + '/version/';

  constructor(private http: HttpClient) {
    super();
  }

  getAll(): Promise<any> {
    throw new Error('Not Implemented');
  }

  getAllByProductId(productUid: string, search: SearchDto): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(this.versionUrl + 'by-product/' + productUid, search).subscribe(res => resolve(res), err => reject(err));
    });
  }

  getByUid(uid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(this.versionUrl + uid).subscribe(res => resolve(res), err => reject(err));
    });
  }

  getGraphForProduct(productUid: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(this.versionUrl + 'graph/' + productUid).subscribe(res => resolve(res), err => reject(err));
    });
  }

  findBySearch(search: SearchDto) {
    throw new Error('Use getAllByProductId method instead');
  }

  save(version: VersionDto): Promise<any> {
    return new Promise((resolve, reject) => {
      if (version.uid) {
        this.http.put(this.versionUrl, version).subscribe(res => resolve(res), err => reject(err));
      } else {
        this.http.post(this.versionUrl, version).subscribe(res => resolve(res), err => reject(err));
      }
    });
  }

  delete(version: VersionDto): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.delete(this.versionUrl + version.uid).subscribe(res => resolve(res), err => reject(err));
    });
  }

}
