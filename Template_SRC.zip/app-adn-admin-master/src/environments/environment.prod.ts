export const environment = {
  production: true,
  serverUrl: '/api/v1',
  serverPublicUrl: '/public/v1'
};
